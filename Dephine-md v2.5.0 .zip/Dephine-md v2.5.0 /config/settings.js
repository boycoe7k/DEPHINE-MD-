const path = require('path')
require('dotenv').config({ path: path.join(__dirname, '../.env') })

const BOT_ROOT = path.join(__dirname, '..')

const config = {
  botName:    process.env.BOT_NAME       || 'DEPHINE-MD',
  prefix:     process.env.PREFIX         || '.',
  ownerNum:   process.env.OWNER_NUMBER   || '263781021754',
  botNum:     process.env.BOT_NUMBER     || '',
  sessionId:  process.env.SESSION_ID     || '',
  authFolder: process.env.AUTH_FOLDER
    ? path.resolve(BOT_ROOT, process.env.AUTH_FOLDER)
    : path.join(BOT_ROOT, 'auth_info_baileys'),
  mode:       process.env.MODE           || 'public',

  autoStatus:    process.env.AUTO_STATUS    === 'true',
  autoReact:     process.env.AUTO_REACT     === 'true',
  autoTyping:    process.env.AUTO_TYPING    === 'true',
  autoRecording: process.env.AUTO_RECORDING === 'true',

  openaiKey: process.env.OPENAI_KEY || '',
  geminiKey: process.env.GEMINI_KEY || '',
  mongoUri:  process.env.MONGO_URI  || '',

  version: '2.0.0',
  startTime: Date.now(),
}

module.exports = config
