require('dotenv').config({ path: require('path').join(__dirname, '.env') })
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys')
const pino     = require('pino')
const { Boom } = require('@hapi/boom')
const fs       = require('fs-extra')
const readline = require('readline')

const config              = require('./config/settings')
const logger              = require('./utils/logger')
const { loadPlugins }     = require('./lib/loader')
const { handleMessage }   = require('./lib/handler')
const { handleAutoReply } = require('./utils/autoReply')
const { processTriggers } = require('./plugins/triggers/triggers')
const { withChannelForward } = require('./utils/channelForward')
const GcStatus               = require('./utils/GcStatus')
const gcState                = require('./utils/gcstate')

let welcomeStore       = new Map()
let goodbyeStore       = new Map()
let pairingRequested   = false

// ── Ask phone number interactively ────────────────────────────────────────────
async function askPhoneNumber() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
    process.stdout.write('  📱 Phone number: ')
    rl.question('', (ans) => {
      rl.close()
      resolve(ans.trim().replace(/[^0-9]/g, ''))
    })
  })
}

async function startBot() {
  pairingRequested = false

  loadPlugins()

  try {
    const gi = require('./plugins/group/group_info')
    welcomeStore = gi.welcomeStore
    goodbyeStore = gi.goodbyeStore
  } catch (_) {}

  await fs.ensureDir(config.authFolder)
  const { state, saveCreds } = await useMultiFileAuthState(config.authFolder)
  const { version }          = await fetchLatestBaileysVersion()

  // ── Print terminal banner ───────────────────────────────────────────────────
  logger.printBanner(config, version.join('.'))

  const alreadyConnected = !!state.creds?.registered

  if (alreadyConnected) {
    logger.printSessionBox('SESSION FOUND — RECONNECTING...', 'green')
  } else {
    logger.printSessionBox('FIRST TIME SETUP — NO SESSION', 'yellow')
  }

  // ── Get phone number ────────────────────────────────────────────────────────
  let phoneNumber = config.botNum?.replace(/[^0-9]/g, '') || ''
  if (!alreadyConnected && !phoneNumber) {
    phoneNumber = await askPhoneNumber()
    console.log()
  }

  // ── Socket — NO makeInMemoryStore ───────────────────────────────────────────
  const conn = makeWASocket({
    version,
    auth:              state,
    printQRInTerminal: false,
    logger:            pino({ level: 'silent' }),
    browser:           ['DEPHINE-MD', 'Chrome', '120.0'],
  })

  conn.ev.on('creds.update', saveCreds)

  // ── GcStatus instance for this connection ───────────────────────────────────
  const gcStatus = new GcStatus(conn)
  gcState.set(gcStatus)

  // ── Global channel-forward wrapper ─────────────────────────────────────────
  // Every outgoing message is automatically tagged as forwarded from the
  // DEPHINE channel regardless of which plugin sends it.
  // Reactions are exempt — they use a different message structure.
  const _origSend = conn.sendMessage.bind(conn)
  conn.sendMessage = (jid, content, opts) => {
    if (content?.react) return _origSend(jid, content, opts)
    return _origSend(jid, withChannelForward(content), opts)
  }

  // ── Request pairing code immediately (outside event handler to avoid races) ─
  if (!alreadyConnected && phoneNumber) {
    setTimeout(async () => {
      if (pairingRequested) return
      pairingRequested = true
      logger.info(`Requesting pairing code — WhatsApp will notify +${phoneNumber}...`)
      try {
        const code = await conn.requestPairingCode(phoneNumber)
        logger.printPairingCode(code)
      } catch (e) {
        logger.error(`Pairing code request failed: ${e.message}`)
        logger.warn('Retrying in 5 seconds...')
        pairingRequested = false
        setTimeout(async () => {
          if (pairingRequested) return
          pairingRequested = true
          try {
            const code = await conn.requestPairingCode(phoneNumber)
            logger.printPairingCode(code)
          } catch (e2) {
            logger.error(`Retry failed: ${e2.message}`)
          }
        }, 5000)
      }
    }, 3000)
  }

  // ── Connection updates ──────────────────────────────────────────────────────
  conn.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update

    if (qr) {
      logger.warn('QR received — pairing code is the preferred method, ignoring QR')
    }

    if (connection === 'open') {
      logger.printConnected(conn.user?.name || conn.user?.id || 'Unknown')
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode
      logger.warn(`Connection closed — code: ${statusCode}`)

      if (statusCode === DisconnectReason.loggedOut) {
        logger.error('Logged out — wiping session and regenerating pairing code...')
        await fs.remove(config.authFolder)
        setTimeout(startBot, 3000)
      } else {
        logger.info('Reconnecting in 5 seconds...')
        setTimeout(startBot, 5000)
      }
    }
  })

  // ── Messages ────────────────────────────────────────────────────────────────
  conn.ev.on('messages.upsert', async (m) => {
    if (m.type !== 'notify') return
    await handleMessage(conn, m).catch(e => logger.error(`Handler: ${e.message}`))
    await processTriggers(conn, m).catch(() => {})
    await handleAutoReply(conn, m).catch(() => {})
  })

  // ── Auto status view & react ─────────────────────────────────────────────────
  if (config.autoStatus) {
    conn.ev.on('messages.upsert', async ({ messages }) => {
      for (const msg of messages) {
        if (msg.key.remoteJid === 'status@broadcast') {
          await conn.readMessages([msg.key]).catch(() => {})
          if (config.autoReact) {
            const emojis = ['🌸','💗','✨','💖','👑','🎀','💫','🌹']
            await conn.sendMessage('status@broadcast', {
              react: { text: emojis[Math.floor(Math.random() * emojis.length)], key: msg.key }
            }).catch(() => {})
          }
        }
      }
    })
  }

  // ── Welcome / goodbye (GcStatus handles per-group config) ──────────────────
  conn.ev.on('group-participants.update', async ({ id, participants, action }) => {
    try {
      const meta = await conn.groupMetadata(id).catch(() => ({}))
      await gcStatus.handleParticipantUpdate(id, action, participants, meta)
    } catch (_) {}
  })

  return conn
}

startBot().catch(err => {
  logger.error(`Fatal: ${err.message}`)
  process.exit(1)
})
