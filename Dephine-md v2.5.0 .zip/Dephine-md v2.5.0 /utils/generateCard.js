// ╔══════════════════════════════════════════════════════════╗
// ║   DEPHINE-MD — CARD IMAGE LOADER                         ║
// ║   Loads custom user images from assets/                  ║
// ║   card_owner.png · card_boycoe.png · menu.png            ║
// ╚══════════════════════════════════════════════════════════╝

const fs   = require('fs-extra')
const path = require('path')

const ASSETS = path.join(__dirname, '../assets')

/**
 * Returns the buffer of the card image for the given type.
 * type: 'owner' | 'boycoe'
 * Always returns the custom PNG placed in assets/.
 */
async function generateCard(type) {
  const file = path.join(ASSETS, `card_${type}.png`)
  if (!fs.existsSync(file)) {
    throw new Error(`Card image not found: assets/card_${type}.png`)
  }
  return file
}

/**
 * Returns the buffer of the menu image.
 */
function getMenuImage() {
  const file = path.join(ASSETS, 'menu.png')
  if (!fs.existsSync(file)) return null
  return fs.readFileSync(file)
}

module.exports = { generateCard, getMenuImage }
