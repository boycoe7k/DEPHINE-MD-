const config = require('../config/settings')

/**
 * Build a DEPHINE-style bordered message block
 * @param {string} title  — section title
 * @param {string[]} lines — body lines (each prefixed with ♡)
 * @param {string} icon   — border icon (default 🌸)
 */
function dephineBox(title, lines, icon = '🌸') {
  const border = `═══════════════════`
  const top    = `┏${icon}${border}${icon}┓`
  const head   = `┃ ${title}`
  const div    = `╠${border}╣`
  const body   = lines.map(l => `┃♡ ${l}`).join('\n')
  const bottom = `┗${icon}${border}${icon}┛`
  return [top, head, div, body, bottom].join('\n')
}

/** Quick reply: error style */
function err(msg) {
  return `❌ *Error:* ${msg}`
}

/** Quick reply: success style */
function ok(msg) {
  return `✅ ${msg}`
}

/** Format uptime ms → human readable */
function formatUptime(ms) {
  const s = Math.floor(ms / 1000)
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return `${d}d ${h}h ${m}m ${sec}s`
}

/** Format file size bytes → human */
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1048576).toFixed(1)} MB`
}

module.exports = { dephineBox, err, ok, formatUptime, formatBytes }
