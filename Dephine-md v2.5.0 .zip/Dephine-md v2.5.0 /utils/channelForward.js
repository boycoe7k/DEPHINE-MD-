// ╔══════════════════════════════════════════════════════╗
// ║   CHANNEL FORWARD CONTEXT INJECTOR                   ║
// ║   Makes every bot reply appear forwarded from the    ║
// ║   DEPHINE channel: https://whatsapp.com/channel/     ║
// ║   0029VbBxPYN2kNFj3I1H1e0f                          ║
// ╚══════════════════════════════════════════════════════╝

// The channel JID format for WhatsApp newsletter/channels
// is: <id>@newsletter
const CHANNEL_JID  = '0029VbBxPYN2kNFj3I1H1e0f@newsletter'
const CHANNEL_NAME = 'DEPHINE-MD 🌸'
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbBxPYN2kNFj3I1H1e0f'

/**
 * Wraps a message content object with forwardingScore + contextInfo
 * so WhatsApp displays it as forwarded from the DEPHINE channel.
 *
 * Usage:
 *   await conn.sendMessage(jid, withChannelForward({ text: 'Hello' }), { quoted: msg })
 *
 * @param {object} content  — Baileys message content (text, image, audio …)
 * @param {number} score    — forwardingScore (≥2 shows "Forwarded many times")
 * @returns {object}        — patched content ready for sendMessage()
 */
function withChannelForward(content, score = 2) {
  return {
    ...content,
    contextInfo: {
      ...(content.contextInfo || {}),
      // Marks message as forwarded
      isForwarded: true,
      forwardingScore: score,
      // Channel/newsletter attribution shown under the message
      forwardedNewsletterMessageInfo: {
        newsletterJid:  CHANNEL_JID,
        newsletterName: CHANNEL_NAME,
        serverMessageId: Math.floor(Math.random() * 9999999),
      },
    },
  }
}

/**
 * Convenience: send any message with channel-forward styling.
 *
 * @param {object} conn     — Baileys socket
 * @param {string} jid      — recipient JID
 * @param {object} content  — message content
 * @param {object} opts     — extra sendMessage options (quoted, etc.)
 */
async function sendForwarded(conn, jid, content, opts = {}) {
  return conn.sendMessage(jid, withChannelForward(content), opts)
}

module.exports = { withChannelForward, sendForwarded, CHANNEL_JID, CHANNEL_NAME, CHANNEL_LINK }
