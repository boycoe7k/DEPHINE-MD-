// ╔══════════════════════════════════════════════════════════╗
// ║   DEPHINE-MD — TERMINAL UI / LOGGER                      ║
// ║   Styled like a cyber intelligence terminal              ║
// ╚══════════════════════════════════════════════════════════╝

const chalk = require('chalk')

// ── Color helpers ─────────────────────────────────────────────────────────────
const pink   = (t) => chalk.hex('#ff69b4')(t)
const rose   = (t) => chalk.hex('#c4516a')(t)
const cyan   = (t) => chalk.hex('#00ffff')(t)
const purple = (t) => chalk.hex('#bf5fff')(t)
const gold   = (t) => chalk.hex('#ffd700')(t)
const green  = (t) => chalk.hex('#00ff88')(t)
const dim    = (t) => chalk.hex('#555555')(t)
const gray   = (t) => chalk.gray(t)
const red    = (t) => chalk.red(t)
const yellow = (t) => chalk.yellow(t)
const white  = (t) => chalk.white(t)

// ── ASCII Banner ──────────────────────────────────────────────────────────────
function printBanner() {
  console.clear()
  console.log()
  console.log(pink('  ██████╗ ███████╗██████╗ ██╗  ██╗██╗███╗   ██╗███████╗'))
  console.log(pink('  ██╔══██╗██╔════╝██╔══██╗██║  ██║██║████╗  ██║██╔════╝'))
  console.log(rose('  ██║  ██║█████╗  ██████╔╝███████║██║██╔██╗ ██║█████╗  '))
  console.log(rose('  ██║  ██║██╔══╝  ██╔═══╝ ██╔══██║██║██║╚██╗██║██╔══╝  '))
  console.log(purple('  ██████╔╝███████╗██║     ██║  ██║██║██║ ╚████║███████╗'))
  console.log(purple('  ╚═════╝ ╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝╚══════╝'))
  console.log()
  console.log(pink('        【 ') + gold('DEPHINE-MD  —  ELEGANT WHATSAPP BOT') + pink(' 】'))
  console.log(dim('              ') + purple('⚡ Powered by Boycoe Dev ⚡'))
  console.log()
}

// ── Info box ──────────────────────────────────────────────────────────────────
function printInfoBox(version, baileyVer, isLatest) {
  console.log(pink('  ┌────────────────────────────────────────────────────┐'))
  console.log(pink('  │') + gray('  🌸  Bot:     ') + cyan(('DEPHINE-MD v' + version).padEnd(38)) + pink('│'))
  console.log(pink('  │') + gray('  🌐  Engine:  ') + cyan('Baileys (Multi-Device)'.padEnd(38))   + pink('│'))
  console.log(pink('  │') + gray('  🔐  Auth:    ') + cyan('Pairing Code Mode (No QR)'.padEnd(38)) + pink('│'))
  console.log(pink('  │') + gray('  👑  Owner:   ') + cyan('Configured in .env'.padEnd(38))        + pink('│'))
  console.log(pink('  └────────────────────────────────────────────────────┘'))
  console.log()
  const latestTxt = isLatest ? green('Yes') : yellow('No')
  console.log(dim('  [') + green('●') + dim('] Baileys v') + cyan(baileyVer) + dim(' | Latest: ') + latestTxt)
  console.log()
}

// ── Session status box ────────────────────────────────────────────────────────
function printSessionBox(label, color) {
  const fn = color === 'green' ? green : color === 'red' ? red : gold
  console.log(dim('  ┌──────────────────────────────────────────────┐'))
  console.log(dim('  │') + '  ' + fn(('🔐  ' + label.toUpperCase()).padEnd(46)) + dim('│'))
  console.log(dim('  └──────────────────────────────────────────────┘'))
  console.log()
}

// ── Pairing code box ──────────────────────────────────────────────────────────
function printPairingCode(code) {
  console.log()
  console.log(pink('  ╔══════════════════════════════════════════════╗'))
  console.log(pink('  ║') + gold('       🔑  YOUR PAIRING CODE                 ') + pink('║'))
  console.log(pink('  ║') + ' '.repeat(46)                                         + pink('║'))
  const pad = Math.floor((46 - code.length) / 2)
  console.log(pink('  ║') + ' '.repeat(pad) + chalk.bold(cyan(code)) + ' '.repeat(46 - pad - code.length) + pink('║'))
  console.log(pink('  ║') + ' '.repeat(46)                                         + pink('║'))
  console.log(pink('  ╠══════════════════════════════════════════════╣'))
  console.log(pink('  ║') + gray('  WhatsApp → Settings → Linked Devices      ') + '  ' + pink('║'))
  console.log(pink('  ║') + gray('  → Link a Device → Enter code above        ') + '  ' + pink('║'))
  console.log(pink('  ╚══════════════════════════════════════════════╝'))
  console.log()
}

// ── Phone number prompt ───────────────────────────────────────────────────────
function printPhonePrompt() {
  console.log(white('  Enter the WhatsApp number to link.'))
  console.log(gray('  Country code, no + or spaces. E.g: 263771234567'))
  console.log()
  process.stdout.write(pink('  📱 Phone number: '))
}

// ── Connected box ─────────────────────────────────────────────────────────────
function printConnected(name, jid) {
  console.log()
  console.log(green('  ╔══════════════════════════════════════════════╗'))
  console.log(green('  ║') + pink('   ✅  DEPHINE-MD CONNECTED SUCCESSFULLY    ') + '  ' + green('║'))
  console.log(green('  ╠══════════════════════════════════════════════╣'))
  console.log(green('  ║') + gray('  👤 Name:   ') + cyan((name || 'Unknown').slice(0,32).padEnd(32)) + '  ' + green('║'))
  console.log(green('  ║') + gray('  📞 JID:    ') + cyan((jid  || '').slice(0,32).padEnd(32))        + '  ' + green('║'))
  console.log(green('  ║') + gray('  🌸 Status: ') + green('Online & Ready'.padEnd(32))               + '  ' + green('║'))
  console.log(green('  ╚══════════════════════════════════════════════╝'))
  console.log()
}

// ── Standard log methods ──────────────────────────────────────────────────────
module.exports = {
  info:    (...a) => console.log(pink('  🌸 [INFO]   '), chalk.white(...a)),
  success: (...a) => console.log(green('  ✅ [OK]     '), chalk.white(...a)),
  warn:    (...a) => console.log(yellow('  ⚠️  [WARN]   '), chalk.white(...a)),
  error:   (...a) => console.log(red('  ❌ [ERROR]  '), chalk.white(...a)),
  cmd:     (...a) => console.log(cyan('  💗 [CMD]    '), chalk.white(...a)),
  conn:    (...a) => console.log(purple('  📶 [CONN]   '), chalk.white(...a)),
  printBanner,
  printInfoBox,
  printSessionBox,
  printPairingCode,
  printPhonePrompt,
  printConnected,
}
