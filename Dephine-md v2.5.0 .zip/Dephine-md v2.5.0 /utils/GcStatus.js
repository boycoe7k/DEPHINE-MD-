'use strict';

const fs   = require('fs');
const path = require('path');
const cron = require('node-cron');

const DATA_FILE = path.join(__dirname, '..', 'data', 'gcstatus_data.json');

function loadData() {
  if (!fs.existsSync(DATA_FILE)) return {};
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch { return {}; }
}

function saveData(data) {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

const IMAGE_EXTS = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
const VIDEO_EXTS = ['.mp4', '.mkv', '.mov', '.avi', '.3gp'];

function detectMime(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (IMAGE_EXTS.includes(ext)) {
    if (ext === '.gif') return { type: 'image', mime: 'image/gif', isGif: true };
    const mime = ext === '.jpg' ? 'image/jpeg' : `image/${ext.slice(1)}`;
    return { type: 'image', mime };
  }
  if (VIDEO_EXTS.includes(ext)) {
    return { type: 'video', mime: `video/${ext.slice(1) === 'mkv' ? 'x-matroska' : ext.slice(1)}` };
  }
  return null;
}

const DEFAULT_CONFIG = {
  enabled: true,
  welcomeEnabled: true,
  welcomeMessage: '🌸 Welcome to *{group}*, @{member}!\nEnjoy your stay 💗',
  goodbyeEnabled: false,
  goodbyeMessage: '💔 Goodbye @{member}, we will miss you!',
  statusPrefix: '📌',
  announcementCron: null,
  announcementMessage: '',
  announcementMedia: null,
  descriptionTemplate: '',
  autoUpdateDescription: false,
  status: '',
  statusMedia: null,
  updatedAt: null,
};

class GcStatus {
  constructor(sock) {
    this.sock     = sock;
    this.data     = loadData();
    this.cronJobs = {};
    this._restore();
  }

  _groupConfig(jid) {
    if (!this.data[jid]) {
      this.data[jid] = { ...DEFAULT_CONFIG };
      saveData(this.data);
    }
    return this.data[jid];
  }

  _save() { saveData(this.data); }

  _fill(tpl, vars = {}) {
    return tpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? `{${k}}`);
  }

  _restore() {
    for (const jid of Object.keys(this.data)) {
      const cfg = this.data[jid];
      if (cfg.announcementCron && (cfg.announcementMessage || cfg.announcementMedia)) {
        this._scheduleCron(jid, cfg.announcementCron, cfg.announcementMessage, cfg.announcementMedia);
      }
    }
  }

  _scheduleCron(jid, cronExpr, message, media = null) {
    if (this.cronJobs[jid]) this.cronJobs[jid].stop();
    if (!cronExpr || !cron.validate(cronExpr)) return false;
    this.cronJobs[jid] = cron.schedule(cronExpr, () => this.sendGroupMedia(jid, message, media));
    return true;
  }

  async sendGroupMedia(jid, caption = '', media = null, mentions = []) {
    try {
      if (!media) {
        await this.sock.sendMessage(jid, { text: caption, mentions });
        return { success: true };
      }

      let buffer, mimetype, info;

      if (media.buffer && media.mimetype) {
        buffer   = media.buffer;
        mimetype = media.mimetype;
        info     = mimetype.startsWith('video')
          ? { type: 'video' }
          : { type: 'image', isGif: mimetype === 'image/gif' };
      } else if (media.filePath) {
        info = detectMime(media.filePath);
        if (!info) throw new Error(`Unsupported file: ${media.filePath}`);
        buffer   = fs.readFileSync(media.filePath);
        mimetype = info.mime;
      } else {
        throw new Error('media must have filePath or { buffer, mimetype }');
      }

      if (info.type === 'image') {
        await this.sock.sendMessage(jid, {
          image: buffer, mimetype, caption, mentions,
          gifPlayback: info.isGif || false,
        });
      } else {
        await this.sock.sendMessage(jid, { video: buffer, mimetype, caption, mentions });
      }

      return { success: true, type: info.type };
    } catch (err) {
      console.error(`[GcStatus] sendGroupMedia ${jid}:`, err.message);
      return { success: false, reason: err.message };
    }
  }

  async setStatus(jid, statusText, { media = null, announce = true, updateDesc = false } = {}) {
    const cfg = this._groupConfig(jid);
    cfg.status      = statusText;
    cfg.updatedAt   = new Date().toISOString();
    cfg.statusMedia = media?.filePath ? { filePath: media.filePath } : null;
    this._save();

    const caption = `${cfg.statusPrefix} *Group Status*\n\n${statusText}`;
    if (announce) await this.sendGroupMedia(jid, caption, media);
    if (updateDesc || cfg.autoUpdateDescription) await this.updateDescription(jid);

    return { success: true, hasMedia: !!media };
  }

  getStatus(jid) {
    const cfg = this._groupConfig(jid);
    return { status: cfg.status || '(none)', updatedAt: cfg.updatedAt, statusMedia: cfg.statusMedia };
  }

  async clearStatus(jid) {
    const cfg = this._groupConfig(jid);
    cfg.status = ''; cfg.statusMedia = null; cfg.updatedAt = new Date().toISOString();
    this._save();
    await this.sock.sendMessage(jid, { text: `${cfg.statusPrefix} Status cleared.` });
    return { success: true };
  }

  async updateDescription(jid, extra = {}) {
    const cfg = this._groupConfig(jid);
    if (!cfg.descriptionTemplate) return { success: false, reason: 'No template set' };
    let meta = {};
    try { meta = await this.sock.groupMetadata(jid); } catch {}
    const desc = this._fill(cfg.descriptionTemplate, {
      status: cfg.status || '', count: meta.participants?.length ?? '?',
      group: meta.subject || 'Group', date: new Date().toLocaleDateString(),
      time: new Date().toLocaleTimeString(), ...extra,
    });
    try {
      await this.sock.groupUpdateDescription(jid, desc);
      return { success: true, desc };
    } catch (err) {
      return { success: false, reason: err.message };
    }
  }

  async handleParticipantUpdate(jid, action, participants, metadata = {}) {
    const cfg = this._groupConfig(jid);
    if (!cfg.enabled) return;
    for (const p of participants) {
      const vars = {
        member: p.replace('@s.whatsapp.net', ''),
        group:  metadata.subject || 'the group',
        count:  metadata.participants?.length ?? '?',
      };
      if (action === 'add' && cfg.welcomeEnabled && cfg.welcomeMessage)
        await this.sock.sendMessage(jid, { text: this._fill(cfg.welcomeMessage, vars), mentions: [p] });
      if (action === 'remove' && cfg.goodbyeEnabled && cfg.goodbyeMessage)
        await this.sock.sendMessage(jid, { text: this._fill(cfg.goodbyeMessage, vars), mentions: [p] });
    }
  }

  scheduleAnnouncement(jid, cronExpr, message, media = null) {
    if (!this._scheduleCron(jid, cronExpr, message, media))
      return { success: false, reason: 'Invalid cron expression' };
    const cfg = this._groupConfig(jid);
    cfg.announcementCron = cronExpr; cfg.announcementMessage = message; cfg.announcementMedia = media;
    this._save();
    return { success: true, cronExpr, hasMedia: !!media };
  }

  stopAnnouncement(jid) {
    if (this.cronJobs[jid]) { this.cronJobs[jid].stop(); delete this.cronJobs[jid]; }
    const cfg = this._groupConfig(jid);
    cfg.announcementCron = null; cfg.announcementMessage = ''; cfg.announcementMedia = null;
    this._save();
    return { success: true };
  }

  configure(jid, patch) { const c = this._groupConfig(jid); Object.assign(c, patch); this._save(); return c; }
  getConfig(jid)        { return this._groupConfig(jid); }
  enable(jid)           { return this.configure(jid, { enabled: true }); }
  disable(jid)          { return this.configure(jid, { enabled: false }); }

  destroy() {
    for (const j of Object.values(this.cronJobs)) j.stop();
    this.cronJobs = {};
  }
}

module.exports = GcStatus;
