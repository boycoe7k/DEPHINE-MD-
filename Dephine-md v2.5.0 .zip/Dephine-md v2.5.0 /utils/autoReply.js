// ╔══════════════════════════════════════════════════════════╗
// ║   AUTO-REPLY MODULE                                       ║
// ║   Every incoming message (even non-command) gets a       ║
// ║   channel-forwarded greeting/prompt if not a command.    ║
// ╚══════════════════════════════════════════════════════════╝

const { withChannelForward } = require('./channelForward')
const config = require('../config/settings')

const GREETINGS = [/^hi$/i, /^hello$/i, /^hey$/i, /^helo$/i, /^hii+$/i, /^sup$/i]
const HOWDY     = [/how are you/i, /how r u/i, /u good/i, /you good/i]
const BOT_ASK   = [/are you a bot/i, /are you real/i, /who are you/i, /what are you/i]

/**
 * Called for EVERY upserted message (not just commands).
 * Sends a channel-forwarded auto-reply when the message matches
 * a greeting / question pattern, or is just plain text with no prefix.
 */
async function handleAutoReply(conn, m) {
  const msg = m.messages?.[0]
  if (!msg || msg.key.fromMe) return

  const jid    = msg.key.remoteJid
  const sender = jid.endsWith('@g.us') ? msg.key.participant : jid

  const body =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text || ''

  if (!body || body.startsWith(config.prefix)) return // Let command handler deal with it

  const lower = body.toLowerCase().trim()

  let reply = null

  if (GREETINGS.some(r => r.test(lower))) {
    reply = `🌸 *Hey there!* Welcome to *${config.botName}*!\n\nType *${config.prefix}menu* to see all commands.\n\n_"Graceful like a queen, powerful like AI."_ ✨`
  } else if (HOWDY.some(r => r.test(lower))) {
    reply = `💗 I'm doing amazing, darling~ Thank you for asking!\n\nHow can I help you today? Type *${config.prefix}menu* to explore. 🌸`
  } else if (BOT_ASK.some(r => r.test(lower))) {
    reply = `🤖 *I am ${config.botName}!*\n\n✨ An elegant, smart WhatsApp bot powered by AI.\n👑 Owner: +${config.ownerNum}\n\nType *${config.prefix}menu* to see what I can do! 💫`
  }

  if (reply) {
    await conn.sendMessage(jid, withChannelForward({ text: reply }), { quoted: msg })
  }
}

module.exports = { handleAutoReply }
