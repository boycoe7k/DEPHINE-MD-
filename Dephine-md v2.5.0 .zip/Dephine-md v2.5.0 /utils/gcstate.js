'use strict';
// Shared singleton so the gcstatus plugin can access the GcStatus instance
// created in index.js after the socket is ready.
let _instance = null;
module.exports = {
  set: (gc) => { _instance = gc; },
  get: () => _instance,
};
