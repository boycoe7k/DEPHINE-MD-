// ╔══════════════════════════╗
// ║   DESIGN / TEXT EFFECTS  ║
// ╚══════════════════════════╝

function applyEffect(text, map) {
  return text.split('').map(c => map[c.toLowerCase()] || map[c] || c).join('')
}

// Unicode character maps
const BOLD_MAP = {
  a:'𝗮',b:'𝗯',c:'𝗰',d:'𝗱',e:'𝗲',f:'𝗳',g:'𝗴',h:'𝗵',i:'𝗶',j:'𝗷',k:'𝗸',l:'𝗹',m:'𝗺',
  n:'𝗻',o:'𝗼',p:'𝗽',q:'𝗾',r:'𝗿',s:'𝘀',t:'𝘁',u:'𝘂',v:'𝘃',w:'𝘄',x:'𝘅',y:'𝘆',z:'𝘇',
  A:'𝗔',B:'𝗕',C:'𝗖',D:'𝗗',E:'𝗘',F:'𝗙',G:'𝗚',H:'𝗛',I:'𝗜',J:'𝗝',K:'𝗞',L:'𝗟',M:'𝗠',
  N:'𝗡',O:'𝗢',P:'𝗣',Q:'𝗤',R:'𝗥',S:'𝗦',T:'𝗧',U:'𝗨',V:'𝗩',W:'𝗪',X:'𝗫',Y:'𝗬',Z:'𝗭'
}
const ITALIC_MAP = {
  a:'𝘢',b:'𝘣',c:'𝘤',d:'𝘥',e:'𝘦',f:'𝘧',g:'𝘨',h:'𝘩',i:'𝘪',j:'𝘫',k:'𝘬',l:'𝘭',m:'𝘮',
  n:'𝘯',o:'𝘰',p:'𝘱',q:'𝘲',r:'𝘳',s:'𝘴',t:'𝘵',u:'𝘶',v:'𝘷',w:'𝘸',x:'𝘹',y:'𝘺',z:'𝘻'
}
const SCRIPT_MAP = {
  a:'𝒶',b:'𝒷',c:'𝒸',d:'𝒹',e:'𝑒',f:'𝒻',g:'𝑔',h:'𝒽',i:'𝒾',j:'𝒿',k:'𝓀',l:'𝓁',m:'𝓂',
  n:'𝓃',o:'𝑜',p:'𝓅',q:'𝓆',r:'𝓇',s:'𝓈',t:'𝓉',u:'𝓊',v:'𝓋',w:'𝓌',x:'𝓍',y:'𝓎',z:'𝓏'
}
const DOUBLE_MAP = {
  a:'𝕒',b:'𝕓',c:'𝕔',d:'𝕕',e:'𝕖',f:'𝕗',g:'𝕘',h:'𝕙',i:'𝕚',j:'𝕛',k:'𝕜',l:'𝕝',m:'𝕞',
  n:'𝕟',o:'𝕠',p:'𝕡',q:'𝕢',r:'𝕣',s:'𝕤',t:'𝕥',u:'𝕦',v:'𝕧',w:'𝕨',x:'𝕩',y:'𝕪',z:'𝕫'
}

function wrapEffect(label, icon, text, transformed) {
  return `${icon} *${label} Effect*\n\n${transformed}\n\n_Original: ${text}_`
}

const metallicHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.metallic <text>`')
  reply(wrapEffect('Metallic', '🔩', text, applyEffect(text, BOLD_MAP)))
}
metallicHandler.command = ['metallic']

const iceHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.ice <text>`')
  const result = applyEffect(text, DOUBLE_MAP)
  reply(wrapEffect('Ice', '🧊', text, `❄️ ${result} ❄️`))
}
iceHandler.command = ['ice']

const snowHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.snow <text>`')
  const spaced = text.split('').join(' ❄ ')
  reply(wrapEffect('Snow', '🌨️', text, `☃️ ${spaced} ☃️`))
}
snowHandler.command = ['snow']

const matrixHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.matrix <text>`')
  const GREEN_BLOCK = '░▒▓'
  const decorated = text.toUpperCase().split('').map(c => `${GREEN_BLOCK[Math.floor(Math.random()*3)]}${c}`).join('')
  reply(wrapEffect('Matrix', '💚', text, `\`\`\`${decorated}\`\`\``))
}
matrixHandler.command = ['matrix']

const neonHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.neon <text>`')
  reply(wrapEffect('Neon', '🌈', text, `【${applyEffect(text, BOLD_MAP)}】`))
}
neonHandler.command = ['neon']

const purpleHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.purple <text>`')
  const result = applyEffect(text, SCRIPT_MAP)
  reply(wrapEffect('Purple', '💜', text, `✨ ${result} ✨`))
}
purpleHandler.command = ['purple']

const glitchHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.glitch <text>`')
  const glitch = ['̶','̷','̴','͟','͢','҉']
  const result = text.split('').map(c => c + glitch[Math.floor(Math.random()*glitch.length)]).join('')
  reply(wrapEffect('Glitch', '📺', text, result))
}
glitchHandler.command = ['glitch']

const fireHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.fire <text>`')
  const result = applyEffect(text, BOLD_MAP)
  reply(wrapEffect('Fire', '🔥', text, `🔥 ${result} 🔥`))
}
fireHandler.command = ['fire']

module.exports = [metallicHandler, iceHandler, snowHandler, matrixHandler, neonHandler, purpleHandler, glitchHandler, fireHandler]
