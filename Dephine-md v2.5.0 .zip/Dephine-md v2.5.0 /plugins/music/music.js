// ╔══════════════════════╗
// ║   MUSIC PLUGIN       ║
// ╚══════════════════════╝

const axios = require('axios')

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)] }

// ── Lyrics ────────────────────────────────────────────────────────────────────
const lyricsHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.lyrics <song name>`')
  reply('🔍 Searching lyrics...')
  try {
    const { data } = await axios.get(
      `https://api.lyrics.ovh/v1/${encodeURIComponent(text.split(' ').slice(0,2).join('/'))}/${encodeURIComponent(text.split(' ').slice(2).join(' ') || text)}`
    )
    const lines = data.lyrics?.trim()
    if (!lines) throw new Error('Not found')
    const preview = lines.split('\n').slice(0, 20).join('\n')
    reply(`🎵 *Lyrics: ${text}*\n\n${preview}\n\n_...use a lyrics site for full song_`)
  } catch {
    reply(`❌ Lyrics not found for: _${text}_`)
  }
}
lyricsHandler.command = ['lyrics']

// ── Spotify Search ────────────────────────────────────────────────────────────
const spotifyHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.spotify <song or artist>`')
  reply('🎧 Searching Spotify...')
  try {
    const { data } = await axios.get(
      `https://saavnapi-nine.vercel.app/search/songs?query=${encodeURIComponent(text)}&page=0&limit=3`
    )
    const songs = data?.data?.results
    if (!songs?.length) throw new Error('No results')
    let msg = `🎵 *Spotify Results: ${text}*\n\n`
    songs.forEach((s, i) => {
      const artist = s.artists?.primary?.[0]?.name || 'Unknown'
      msg += `*${i+1}.* ${s.name}\n👤 ${artist} | ⏱️ ${Math.floor(s.duration/60)}:${String(s.duration%60).padStart(2,'0')}\n🔗 ${s.url || 'N/A'}\n\n`
    })
    reply(msg.trim())
  } catch {
    reply(`❌ No results for: _${text}_`)
  }
}
spotifyHandler.command = ['spotify']

// ── Playlist ──────────────────────────────────────────────────────────────────
const playlistHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.playlist <genre or mood>`')
  const moods = {
    chill: ['lo-fi beats','Chillhop Music','Study Music'],
    sad:   ['Sad Vibes','Emotional Songs','Heartbreak Playlist'],
    happy: ['Good Vibes','Party Hits','Feel Good Music'],
    hype:  ['Trap Nation','Bass Boosted','Workout Hits'],
    love:  ['Love Songs','Romantic Playlist','Date Night'],
  }
  const key = Object.keys(moods).find(k => text.toLowerCase().includes(k)) || 'chill'
  const suggestions = moods[key]
  reply(`🎶 *${text} Playlist Suggestions:*\n\n${suggestions.map((s,i)=>`${i+1}. 🎵 ${s}`).join('\n')}\n\n_Search these on Spotify or YouTube_`)
}
playlistHandler.command = ['playlist']

// ── Now Playing ───────────────────────────────────────────────────────────────
const VIBES = [
  { title: 'Blinding Lights', artist: 'The Weeknd', duration: '3:20' },
  { title: 'As It Was', artist: 'Harry Styles', duration: '2:37' },
  { title: 'Stay', artist: 'The Kid LAROI & Justin Bieber', duration: '2:21' },
  { title: 'Golden Hour', artist: 'JVKE', duration: '3:29' },
  { title: 'Flowers', artist: 'Miley Cyrus', duration: '3:21' },
]
const nowplayingHandler = async ({ reply }) => {
  const s = pick(VIBES)
  reply(`🎵 *Now Playing on DEPHINE Radio*\n\n🎶 ${s.title}\n👤 ${s.artist}\n⏱️ ${s.duration}\n\n_Tune in at_ 🌸`)
}
nowplayingHandler.command = ['nowplaying', 'np']

// ── Artist ────────────────────────────────────────────────────────────────────
const artistHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.artist <name>`')
  try {
    const { data } = await axios.get(
      `https://saavnapi-nine.vercel.app/search/artists?query=${encodeURIComponent(text)}&page=0&limit=1`
    )
    const a = data?.data?.results?.[0]
    if (!a) throw new Error()
    reply(`👤 *${a.name}*\n\n🎵 Follower count: ${a.followerCount || 'N/A'}\n🌐 ${a.url || 'N/A'}`)
  } catch {
    reply(`❌ Artist not found: _${text}_`)
  }
}
artistHandler.command = ['artist']

// ── Album ─────────────────────────────────────────────────────────────────────
const albumHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.album <name>`')
  try {
    const { data } = await axios.get(
      `https://saavnapi-nine.vercel.app/search/albums?query=${encodeURIComponent(text)}&page=0&limit=1`
    )
    const a = data?.data?.results?.[0]
    if (!a) throw new Error()
    reply(`💿 *${a.name}*\n👤 ${a.artists?.primary?.[0]?.name || 'Unknown'}\n📅 ${a.year || 'N/A'}\n🎵 ${a.songCount || '?'} songs\n🔗 ${a.url || 'N/A'}`)
  } catch {
    reply(`❌ Album not found: _${text}_`)
  }
}
albumHandler.command = ['album']

// ── SoundCloud ────────────────────────────────────────────────────────────────
const soundcloudHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.soundcloud <url or title>`')
  reply(`🎵 SoundCloud downloader coming soon!\n_Search:_ ${text}\n_Visit:_ soundcloud.com`)
}
soundcloudHandler.command = ['soundcloud', 'sc']

// ── Audiomack ─────────────────────────────────────────────────────────────────
const audiomackHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.audiomack <url>`')
  reply(`🎵 Audiomack downloader coming soon!\n_Visit:_ audiomack.com`)
}
audiomackHandler.command = ['audiomack']

module.exports = [lyricsHandler, spotifyHandler, playlistHandler, nowplayingHandler, artistHandler, albumHandler, soundcloudHandler, audiomackHandler]
