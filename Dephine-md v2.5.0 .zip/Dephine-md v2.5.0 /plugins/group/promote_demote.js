// ╔══════════════════════╗
// ║  .promote / .demote  ║
// ╚══════════════════════╝

const promoteHandler = async ({ conn, msg, jid, reply, isBotAdmin, quoted }) => {
  if (!isBotAdmin) return reply('👑 Make me an admin first!')
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target = mentioned[0] || quoted?.sender
  if (!target) return reply('❓ Tag or reply to a member to promote.')
  await conn.groupParticipantsUpdate(jid, [target], 'promote')
  reply(`👑 *@${target.split('@')[0]}* has been promoted to admin!`)
}
promoteHandler.command = ['promote']
promoteHandler.group   = true
promoteHandler.admin   = true

const demoteHandler = async ({ conn, msg, jid, reply, isBotAdmin, quoted }) => {
  if (!isBotAdmin) return reply('👑 Make me an admin first!')
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target = mentioned[0] || quoted?.sender
  if (!target) return reply('❓ Tag or reply to an admin to demote.')
  await conn.groupParticipantsUpdate(jid, [target], 'demote')
  reply(`💗 *@${target.split('@')[0]}* has been demoted to member.`)
}
demoteHandler.command = ['demote']
demoteHandler.group   = true
demoteHandler.admin   = true

// Export both — loader handles arrays
module.exports = [promoteHandler, demoteHandler]
