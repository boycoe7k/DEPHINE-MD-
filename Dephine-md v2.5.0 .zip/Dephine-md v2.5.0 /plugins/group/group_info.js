// ╔══════════════════════════════════════════╗
// ║  setname · setdesc · revoke · gc · etc.  ║
// ╚══════════════════════════════════════════╝

const welcomeStore = new Map() // jid => boolean
const goodbyeStore = new Map()

const setnameHandler = async ({ conn, jid, reply, text, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights!')
  if (!text) return reply('❓ Usage: `.setname New Group Name`')
  await conn.groupUpdateSubject(jid, text)
  reply(`✅ Group name updated to *${text}*`)
}
setnameHandler.command = ['setname']
setnameHandler.group   = true
setnameHandler.admin   = true

const setdescHandler = async ({ conn, jid, reply, text, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights!')
  if (!text) return reply('❓ Usage: `.setdesc Your description here`')
  await conn.groupUpdateDescription(jid, text)
  reply('✅ Group description updated!')
}
setdescHandler.command = ['setdesc']
setdescHandler.group   = true
setdescHandler.admin   = true

const revokeHandler = async ({ conn, jid, reply, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights!')
  const code = await conn.groupRevokeInvite(jid)
  reply(`🔗 New invite link generated:\nhttps://chat.whatsapp.com/${code}`)
}
revokeHandler.command = ['revoke', 'resetlink']
revokeHandler.group   = true
revokeHandler.admin   = true

const creategcHandler = async ({ conn, reply, text, sender }) => {
  if (!text) return reply('❓ Usage: `.creategc Group Name`')
  const group = await conn.groupCreate(text, [sender])
  reply(`🌸 Group *${text}* created!\nID: ${group.id}`)
}
creategcHandler.command = ['creategc']
creategcHandler.owner   = true

const leavegcHandler = async ({ conn, jid, reply }) => {
  reply('💗 Leaving the group now. Goodbye~')
  setTimeout(() => conn.groupLeave(jid), 1500)
}
leavegcHandler.command = ['leavegc']
leavegcHandler.group   = true
leavegcHandler.owner   = true

const welcomeHandler = async ({ jid, reply, args }) => {
  const toggle = args[0]?.toLowerCase()
  if (!toggle) return reply('❓ Usage: `.welcome on|off`')
  welcomeStore.set(jid, toggle === 'on')
  reply(`🌸 Welcome messages *${toggle === 'on' ? 'enabled' : 'disabled'}*.`)
}
welcomeHandler.command = ['welcome']
welcomeHandler.group   = true
welcomeHandler.admin   = true

const goodbyeHandler = async ({ jid, reply, args }) => {
  const toggle = args[0]?.toLowerCase()
  if (!toggle) return reply('❓ Usage: `.goodbye on|off`')
  goodbyeStore.set(jid, toggle === 'on')
  reply(`💗 Goodbye messages *${toggle === 'on' ? 'enabled' : 'disabled'}*.`)
}
goodbyeHandler.command = ['goodbye']
goodbyeHandler.group   = true
goodbyeHandler.admin   = true

module.exports = {
  welcomeStore, goodbyeStore,
  handlers: [setnameHandler, setdescHandler, revokeHandler, creategcHandler, leavegcHandler, welcomeHandler, goodbyeHandler]
}
