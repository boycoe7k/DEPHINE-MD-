// ╔══════════════════╗
// ║  .ban / .unban   ║
// ╚══════════════════╝

const handler = async ({ conn, msg, jid, reply, isAdmin, isBotAdmin, text, quoted }) => {
  if (!isAdmin) return reply('💗 Only *admins* can use this, darling~')
  if (!isBotAdmin) return reply('👑 Make me an admin first!')

  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target = mentioned[0] || quoted?.sender
  if (!target) return reply('❓ Tag or reply to a member to ban.')

  await conn.groupParticipantsUpdate(jid, [target], 'remove')
  reply(`🌸 *@${target.split('@')[0]}* has been removed from the group.`)
}

handler.command = ['ban', 'kick']
handler.group   = true
handler.admin   = true
module.exports  = handler
