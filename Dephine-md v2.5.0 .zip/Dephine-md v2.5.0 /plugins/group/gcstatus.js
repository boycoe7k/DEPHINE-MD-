'use strict';
// ╔══════════════════════════════════════════════╗
// ║  GcStatus Plugin — Group Status Management   ║
// ║  Commands: .gcstatus <subcommand>            ║
// ╚══════════════════════════════════════════════╝

const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const gcState = require('../../utils/gcstate');

async function extractQuotedMedia(msg) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!ctx) return null;
  try {
    if (ctx.imageMessage) {
      const buffer = await downloadMediaMessage(
        { message: { imageMessage: ctx.imageMessage }, key: {} }, 'buffer', {}
      );
      return { buffer, mimetype: ctx.imageMessage.mimetype || 'image/jpeg' };
    }
    if (ctx.videoMessage) {
      const buffer = await downloadMediaMessage(
        { message: { videoMessage: ctx.videoMessage }, key: {} }, 'buffer', {}
      );
      return { buffer, mimetype: ctx.videoMessage.mimetype || 'video/mp4' };
    }
  } catch (_) {}
  return null;
}

const HELP = `📖 *GcStatus v2.0 — Commands*

*.gcstatus set* <caption>        — set status (quote image/video)
*.gcstatus photo* <caption>      — set image status (quote image)
*.gcstatus video* <caption>      — set video status (quote video)
*.gcstatus get*                  — show current status
*.gcstatus clear*                — clear status
*.gcstatus welcome* <msg>        — set join message ({member},{group})
*.gcstatus goodbye* <msg>        — set leave message
*.gcstatus announce* <cron> :: <msg> — schedule (quote media optional)
*.gcstatus stopannounce*         — stop scheduled announcement
*.gcstatus desc* <template>      — set description template
*.gcstatus updatedesc*           — push description now
*.gcstatus enable / disable*     — toggle plugin for this group
*.gcstatus config*               — show current config`;

const handler = async (ctx) => {
  const { conn, msg, jid, text, reply, isAdmin, isOwner } = ctx;

  if (!isAdmin && !isOwner) return reply('⚠️ *Admins only.*');

  const gc = gcState.get();
  if (!gc) return reply('❌ GcStatus not ready yet — try again in a moment.');

  const [sub, ...rest] = text.trim().split(/\s+/);
  const body = rest.join(' ');

  const send = (t, media = null) => gc.sendGroupMedia(jid, t, media);

  switch ((sub || '').toLowerCase()) {

    case 'set': {
      const media = await extractQuotedMedia(msg);
      const r = await gc.setStatus(jid, body || '📌 Status updated', { media });
      await send(r.success ? `✅ Status set${r.hasMedia ? ' with media 📎' : ''}!` : '❌ Failed.');
      break;
    }

    case 'image':
    case 'photo': {
      const media = await extractQuotedMedia(msg);
      if (!media) return send('📎 Quote an image together with this command.');
      await gc.setStatus(jid, body || '', { media });
      await send('✅ Image status set!');
      break;
    }

    case 'video': {
      const media = await extractQuotedMedia(msg);
      if (!media) return send('📎 Quote a video together with this command.');
      await gc.setStatus(jid, body || '', { media });
      await send('✅ Video status set!');
      break;
    }

    case 'get': {
      const { status, updatedAt, statusMedia } = gc.getStatus(jid);
      const caption = `📌 *Status*\n\n${status}\n\n_Updated: ${updatedAt || 'never'}_`;
      await send(caption, statusMedia ? { filePath: statusMedia.filePath } : null);
      break;
    }

    case 'clear':
      await gc.clearStatus(jid);
      break;

    case 'welcome':
      gc.configure(jid, { welcomeMessage: body, welcomeEnabled: true });
      await send(`✅ Welcome message set!\n_${body}_`);
      break;

    case 'goodbye':
      gc.configure(jid, { goodbyeMessage: body, goodbyeEnabled: true });
      await send(`✅ Goodbye message set!\n_${body}_`);
      break;

    case 'announce': {
      const sep = body.indexOf('::');
      if (sep === -1) return send('Usage: .gcstatus announce <cron> :: <message>');
      const cronExpr = body.slice(0, sep).trim();
      const message  = body.slice(sep + 2).trim();
      const media    = await extractQuotedMedia(msg);
      const r = gc.scheduleAnnouncement(jid, cronExpr, message, media);
      await send(r.success
        ? `✅ Announcement scheduled!\nCron: \`${cronExpr}\`${r.hasMedia ? '\n📎 with media' : ''}`
        : `❌ ${r.reason}`);
      break;
    }

    case 'stopannounce':
      gc.stopAnnouncement(jid);
      await send('✅ Announcement stopped.');
      break;

    case 'desc':
      gc.configure(jid, { descriptionTemplate: body, autoUpdateDescription: true });
      await send('✅ Description template saved!');
      break;

    case 'updatedesc': {
      const r = await gc.updateDescription(jid);
      await send(r.success ? `✅ Description updated!` : `❌ ${r.reason}`);
      break;
    }

    case 'enable':
      gc.enable(jid);
      await send('✅ GcStatus enabled for this group.');
      break;

    case 'disable':
      gc.disable(jid);
      await send('⛔ GcStatus disabled for this group.');
      break;

    case 'config': {
      const c = gc.getConfig(jid);
      await send([
        '⚙️ *GcStatus Config*',
        `• Enabled: ${c.enabled}`,
        `• Welcome: ${c.welcomeEnabled}`,
        `• Goodbye: ${c.goodbyeEnabled}`,
        `• Auto-desc: ${c.autoUpdateDescription}`,
        `• Cron: ${c.announcementCron || 'none'}`,
        `• Media status: ${c.statusMedia ? '✅' : 'none'}`,
        `• Status: ${c.status || '(none)'}`,
      ].join('\n'));
      break;
    }

    default:
      await send(HELP);
  }
};

handler.command     = ['gcstatus'];
handler.group       = true;
handler.admin       = true;
handler.description = 'Group status — set/get/clear/announce/welcome/goodbye';

module.exports = handler;
