// ╔═════════════════════════════════╗
// ║  .mute .unmute .lockgroup etc.  ║
// ╚═════════════════════════════════╝

const muteHandler = async ({ conn, jid, reply, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights to mute the group!')
  await conn.groupSettingUpdate(jid, 'announcement') // only admins send
  reply('🔇 Group has been *muted*. Only admins can send messages.')
}
muteHandler.command = ['mute']
muteHandler.group   = true
muteHandler.admin   = true

const unmuteHandler = async ({ conn, jid, reply, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights!')
  await conn.groupSettingUpdate(jid, 'not_announcement')
  reply('🔊 Group has been *unmuted*. Everyone can send messages.')
}
unmuteHandler.command = ['unmute']
unmuteHandler.group   = true
unmuteHandler.admin   = true

const lockHandler = async ({ conn, jid, reply, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights!')
  await conn.groupSettingUpdate(jid, 'locked')
  reply('🔒 Group info is now *locked* to admins only.')
}
lockHandler.command = ['lockgroup']
lockHandler.group   = true
lockHandler.admin   = true

const unlockHandler = async ({ conn, jid, reply, isBotAdmin }) => {
  if (!isBotAdmin) return reply('👑 I need admin rights!')
  await conn.groupSettingUpdate(jid, 'unlocked')
  reply('🔓 Group info is now *unlocked*.')
}
unlockHandler.command = ['unlockgroup']
unlockHandler.group   = true
unlockHandler.admin   = true

const slowmodeHandler = async ({ conn, jid, reply, args }) => {
  const seconds = parseInt(args[0])
  if (isNaN(seconds) || seconds < 1) return reply('❓ Usage: `.slowmode 10` (seconds)')
  // Baileys doesn't expose slowmode directly — send as group update message
  reply(`⏱️ Slow mode set to *${seconds} seconds*.\n_(Configure via WhatsApp group settings)_`)
}
slowmodeHandler.command = ['slowmode']
slowmodeHandler.group   = true
slowmodeHandler.admin   = true

module.exports = [muteHandler, unmuteHandler, lockHandler, unlockHandler, slowmodeHandler]
