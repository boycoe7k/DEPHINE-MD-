// ╔══════════════════════════════════════════════════════════╗
// ║   DEPHINE-MD — VOICE MESSAGE PLUGIN                      ║
// ║   .tts .voicegreeting .voicelove .voicemotivation        ║
// ║   .voicejoke .voicebotinfo .voicenews .voiceweather      ║
// ╚══════════════════════════════════════════════════════════╝

const axios  = require('axios')
const fs     = require('fs-extra')
const path   = require('path')
const { withChannelForward } = require('../../utils/channelForward')
const config = require('../../config/settings')

const TMP = path.join(__dirname, '../../tmp')
fs.ensureDirSync(TMP)

async function ttsToBuffer(text, lang = 'en') {
  const clean = text.slice(0, 200).replace(/[*_~`]/g, '')
  const url   = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(clean)}&tl=${lang}&client=tw-ob`
  const res   = await axios.get(url, {
    responseType: 'arraybuffer', timeout: 15000,
    headers: { 'User-Agent': 'Mozilla/5.0' },
  })
  return Buffer.from(res.data)
}

async function sendVoice(conn, jid, msg, textToSpeak, lang = 'en') {
  const buf = await ttsToBuffer(textToSpeak, lang)
  const out = path.join(TMP, `voice_${Date.now()}.ogg`)
  await fs.outputFile(out, buf)
  await conn.sendMessage(jid, withChannelForward({
    audio: fs.readFileSync(out),
    mimetype: 'audio/ogg; codecs=opus',
    ptt: true,
  }), { quoted: msg })
  fs.remove(out)
}

const ttsHandler = async ({ conn, jid, msg, reply, args, text }) => {
  const langMatch = args[0]?.match(/^[a-z]{2}(-[A-Z]{2})?$/)
  const lang   = langMatch ? args[0] : 'en'
  const speech = langMatch ? args.slice(1).join(' ') : text
  if (!speech) return reply(
`🎙️ *Text to Speech*
❓ *Usage:* \`.tts <text>\`
Language: \`.tts es Hola amigos\`
Codes: \`en\` \`es\` \`fr\` \`de\` \`pt\` \`ar\` \`hi\` \`zh\` \`sw\``)
  reply('🎙️ Converting to voice...')
  try { await sendVoice(conn, jid, msg, speech, lang) }
  catch (e) { reply(`❌ TTS failed: ${e.message}`) }
}
ttsHandler.command = ['tts', 'speak', 'voice']

const voicegreetingHandler = async ({ conn, jid, msg, reply }) => {
  reply('🎙️ Sending voice greeting...')
  const h = new Date().getHours()
  const g = h < 12
    ? 'Good morning! This is DEPHINE, your elegant smart assistant. Have a wonderful day!'
    : h < 17
    ? 'Good afternoon! DEPHINE here, always ready to help you!'
    : 'Good evening! DEPHINE speaking. Relax and let me take care of everything tonight!'
  try { await sendVoice(conn, jid, msg, g) }
  catch (e) { reply(`❌ Voice failed: ${e.message}`) }
}
voicegreetingHandler.command = ['voicegreeting', 'vgreet']

const voiceloveHandler = async ({ conn, jid, msg, reply }) => {
  reply('💗 Sending love voice message...')
  const msgs = [
    'Hey you! Yes, you! You are absolutely amazing and I just wanted to remind you of that. DEPHINE loves you!',
    'You are braver than you believe, stronger than you seem, and smarter than you think. Keep shining, beautiful!',
    'Just a quick reminder from DEPHINE that you are loved, appreciated, and so very special. Never forget that!',
    'The world is a better place because you are in it. DEPHINE cares about you so much!',
  ]
  try { await sendVoice(conn, jid, msg, msgs[Math.floor(Math.random() * msgs.length)]) }
  catch (e) { reply(`❌ Voice failed: ${e.message}`) }
}
voiceloveHandler.command = ['voicelove', 'vlove']

const voicemotivationHandler = async ({ conn, jid, msg, reply }) => {
  reply('💪 Sending motivation...')
  const qs = [
    'Success is not final, failure is not fatal. It is the courage to continue that counts. Keep going!',
    'Every morning you have two choices: continue to sleep with your dreams, or wake up and chase them!',
    'You did not come this far to only come this far. Push through and make it happen today!',
    'Your only limit is your mind. Believe you can and you are already halfway there. DEPHINE believes in you!',
  ]
  try { await sendVoice(conn, jid, msg, qs[Math.floor(Math.random() * qs.length)]) }
  catch (e) { reply(`❌ Voice failed: ${e.message}`) }
}
voicemotivationHandler.command = ['voicemotivation', 'vmotivate', 'motivate']

const voicejokeHandler = async ({ conn, jid, msg, reply }) => {
  reply('😂 Sending voice joke...')
  const jokes = [
    'Why do scientists not trust atoms? Because they make up everything! Ha ha!',
    'I told my wife she was drawing her eyebrows too high. She looked surprised!',
    'Why did the scarecrow win an award? Because he was outstanding in his field!',
    'What do you call a fish without eyes? A fsh! No eyes, no i!',
  ]
  try { await sendVoice(conn, jid, msg, jokes[Math.floor(Math.random() * jokes.length)]) }
  catch (e) { reply(`❌ Voice failed: ${e.message}`) }
}
voicejokeHandler.command = ['voicejoke', 'vjoke']

const voicebotinfoHandler = async ({ conn, jid, msg, reply }) => {
  reply('🤖 Introducing myself...')
  const t = `Hello! I am ${config.botName}, an elegant and powerful WhatsApp bot. I can help you with music, AI, group management, fun games and so much more! Type dot menu to see all my commands. My owner is available at plus ${config.ownerNum}.`
  try { await sendVoice(conn, jid, msg, t) }
  catch (e) { reply(`❌ Voice failed: ${e.message}`) }
}
voicebotinfoHandler.command = ['voicebotinfo', 'vbotinfo', 'introduce']

const voiceweatherHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.voiceweather <city>`')
  reply(`🌤️ Getting weather for *${text}*...`)
  try {
    const { data } = await axios.get(`https://wttr.in/${encodeURIComponent(text)}?format=3`, { timeout: 8000 })
    await sendVoice(conn, jid, msg, `Weather update for ${text}. ${data}`)
  } catch (e) { reply(`❌ Voice weather failed: ${e.message}`) }
}
voiceweatherHandler.command = ['voiceweather', 'vweather']

const voicenewsHandler = async ({ conn, jid, msg, reply }) => {
  reply('📰 Preparing voice news...')
  try {
    const { data } = await axios.get('https://gnews.io/api/v4/top-headlines?lang=en&max=1&token=demo', { timeout: 8000 })
    const art = data?.articles?.[0]
    if (!art) throw new Error()
    await sendVoice(conn, jid, msg, `Breaking news from ${art.source.name}. ${art.title}. ${art.description || ''}`)
  } catch {
    await sendVoice(conn, jid, msg, 'Good day! This is DEPHINE news update. Type dot news to read the latest stories!').catch(() => reply('❌ Voice news failed.'))
  }
}
voicenewsHandler.command = ['voicenews', 'vnews']

module.exports = [ttsHandler, voicegreetingHandler, voiceloveHandler, voicemotivationHandler, voicejokeHandler, voicebotinfoHandler, voiceweatherHandler, voicenewsHandler]
