// ╔══════════════════════════════════════════════════════════╗
// ║   DEPHINE-MD — GROUP SCHEDULER                           ║
// ║   Admins can set open/close times for the group          ║
// ║   Bot auto-mutes/unmutes and sends styled announcements  ║
// ║   .schedule .unschedule .scheduleinfo .opengroup         ║
// ║   .closegroup                                            ║
// ╚══════════════════════════════════════════════════════════╝

const { withChannelForward } = require('../../utils/channelForward')
const config = require('../../config/settings')

// scheduleStore: jid => { openTime, closeTime, timezone, openMsg, closeMsg, job }
const scheduleStore = new Map()

// ── Time parser: "08:00" => { hour, minute } ──────────────────────────────────
function parseTime(str) {
  const match = str.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i)
  if (!match) return null
  let hour = parseInt(match[1])
  const min  = parseInt(match[2])
  const ampm = match[3]?.toUpperCase()
  if (ampm === 'PM' && hour < 12) hour += 12
  if (ampm === 'AM' && hour === 12) hour = 0
  if (hour < 0 || hour > 23 || min < 0 || min > 59) return null
  return { hour, min }
}

// ── Get ms until next occurrence of HH:MM in a timezone ──────────────────────
function msUntilNext(hour, min, timezone) {
  const now  = new Date()
  const nowInTZ = new Date(now.toLocaleString('en-US', { timeZone: timezone }))
  const target  = new Date(nowInTZ)
  target.setHours(hour, min, 0, 0)
  if (target <= nowInTZ) target.setDate(target.getDate() + 1)
  return target - nowInTZ
}

// ── Format time for display ───────────────────────────────────────────────────
function fmtTime(hour, min) {
  const h   = hour % 12 || 12
  const m   = String(min).padStart(2, '0')
  const apm = hour < 12 ? 'AM' : 'PM'
  return `${h}:${m} ${apm}`
}

// ── Send open announcement ────────────────────────────────────────────────────
async function sendOpenAnnouncement(conn, jid, customMsg) {
  const now = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  const text = customMsg ||
`🌅 *Good Morning, Everyone!* 🌸

┏🟢═══════════════════╗
┃ ✅ GROUP IS NOW OPEN
╠═══════════════════╣
┃ 🕐 Time: ${now}
┃ 💬 You may now send messages!
┃ 🌸 Have a wonderful day~
╠═══════════════════╣
┃ 👑 Managed by ${config.botName}
┗🟢═══════════════════╝

_Respect the rules and enjoy chatting!_ 💕`

  await conn.sendMessage(jid, withChannelForward({ text }))
}

// ── Send close announcement ───────────────────────────────────────────────────
async function sendCloseAnnouncement(conn, jid, customMsg) {
  const now = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  const text = customMsg ||
`🌙 *Good Night, Everyone!* 🌸

┏🔴═══════════════════╗
┃ 🔒 GROUP IS NOW CLOSED
╠═══════════════════╣
┃ 🕐 Time: ${now}
┃ 🔇 Messages are paused for now.
┃ 🌙 Rest well, see you tomorrow~
╠═══════════════════╣
┃ 👑 Managed by ${config.botName}
┗🔴═══════════════════╝

_"Sleep is the best meditation."_ 💫 Goodnight! 🌙`

  await conn.sendMessage(jid, withChannelForward({ text }))
}

// ── Schedule job runner ───────────────────────────────────────────────────────
function scheduleGroup(conn, jid, entry) {
  // Clear existing timers
  if (entry._openTimer)  clearTimeout(entry._openTimer)
  if (entry._closeTimer) clearTimeout(entry._closeTimer)

  const tz = entry.timezone || 'UTC'

  // Open timer
  const msOpen = msUntilNext(entry.openHour, entry.openMin, tz)
  entry._openTimer = setTimeout(async function openFn() {
    try {
      await conn.groupSettingUpdate(jid, 'not_announcement')
      await sendOpenAnnouncement(conn, jid, entry.openMsg)
    } catch (_) {}
    entry._openTimer = setTimeout(openFn, 24 * 3600 * 1000)
  }, msOpen)

  // Close timer
  const msClose = msUntilNext(entry.closeHour, entry.closeMin, tz)
  entry._closeTimer = setTimeout(async function closeFn() {
    try {
      await conn.groupSettingUpdate(jid, 'announcement')
      await sendCloseAnnouncement(conn, jid, entry.closeMsg)
    } catch (_) {}
    entry._closeTimer = setTimeout(closeFn, 24 * 3600 * 1000)
  }, msClose)

  scheduleStore.set(jid, entry)
}

// ── .schedule ─────────────────────────────────────────────────────────────────
// Usage: .schedule 07:00 22:00 [Africa/Harare]
const scheduleHandler = async ({ conn, jid, reply, args, isAdmin, isBotAdmin }) => {
  if (!isAdmin) return reply('💗 Only *admins* can set a schedule.')
  if (!isBotAdmin) return reply('👑 Make me an admin first!')
  if (args.length < 2) return reply(
`❓ *Usage:* \`.schedule <open_time> <close_time> [timezone]\`

Examples:
  \`.schedule 07:00 22:00\`
  \`.schedule 08:00 AM 10:00 PM Africa/Harare\`
  \`.schedule 06:30 23:00 America/New_York\`

Common timezones:
  Africa/Harare · Africa/Nairobi · Africa/Lagos
  America/New_York · Europe/London · Asia/Dubai`)

  const openStr  = args[0]
  const closeStr = args[1]
  const tz       = args[2] || 'Africa/Harare'

  const open  = parseTime(openStr)
  const close = parseTime(closeStr)

  if (!open)  return reply(`❌ Invalid open time: *${openStr}*\nFormat: \`07:00\` or \`7:00 AM\``)
  if (!close) return reply(`❌ Invalid close time: *${closeStr}*\nFormat: \`22:00\` or \`10:00 PM\``)

  try { new Intl.DateTimeFormat('en', { timeZone: tz }) }
  catch { return reply(`❌ Unknown timezone: *${tz}*`) }

  const entry = {
    openHour: open.hour, openMin: open.min,
    closeHour: close.hour, closeMin: close.min,
    timezone: tz,
    openMsg: null, closeMsg: null,
    _openTimer: null, _closeTimer: null,
  }

  scheduleGroup(conn, jid, entry)

  const msO = msUntilNext(open.hour, open.min, tz)
  const msC = msUntilNext(close.hour, close.min, tz)
  const nextOpen  = new Date(Date.now() + msO).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})
  const nextClose = new Date(Date.now() + msC).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})

  reply(
`✅ *Group Schedule Set!*
┏📅═══════════════════╗
┃ 🟢 Opens:  *${fmtTime(open.hour, open.min)}*
┃ 🔴 Closes: *${fmtTime(close.hour, close.min)}*
┃ 🌍 Timezone: ${tz}
╠═══════════════════╣
┃ ⏳ Next open in:  ~${Math.round(msO/60000)}m
┃ ⏳ Next close in: ~${Math.round(msC/60000)}m
╠═══════════════════╣
┃ 💡 Set custom messages:
┃ .setopenmsg <message>
┃ .setclosemsg <message>
┗📅═══════════════════╝

_I will automatically open & close this group daily._ 🌸`)
}
scheduleHandler.command = ['schedule', 'setschedule']
scheduleHandler.group   = true
scheduleHandler.admin   = true

// ── .setopenmsg ───────────────────────────────────────────────────────────────
const setopenmsgHandler = async ({ jid, reply, text, isAdmin }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  if (!text) return reply('❓ Usage: `.setopenmsg Good morning everyone! Group is open 🌅`')
  const entry = scheduleStore.get(jid)
  if (!entry) return reply('❌ No schedule set. Use `.schedule` first.')
  entry.openMsg = text
  reply(`✅ *Open message updated!*\n\n_"${text}"_\n\n_This will be sent when the group opens daily._ 🌅`)
}
setopenmsgHandler.command = ['setopenmsg']
setopenmsgHandler.group   = true
setopenmsgHandler.admin   = true

// ── .setclosemsg ──────────────────────────────────────────────────────────────
const setclosemsgHandler = async ({ jid, reply, text, isAdmin }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  if (!text) return reply('❓ Usage: `.setclosemsg Goodnight everyone! See you tomorrow 🌙`')
  const entry = scheduleStore.get(jid)
  if (!entry) return reply('❌ No schedule set. Use `.schedule` first.')
  entry.closeMsg = text
  reply(`✅ *Close message updated!*\n\n_"${text}"_\n\n_This will be sent when the group closes daily._ 🌙`)
}
setclosemsgHandler.command = ['setclosemsg']
setclosemsgHandler.group   = true
setclosemsgHandler.admin   = true

// ── .unschedule ───────────────────────────────────────────────────────────────
const unscheduleHandler = async ({ jid, reply, isAdmin }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  const entry = scheduleStore.get(jid)
  if (!entry) return reply('❌ No schedule active in this group.')
  clearTimeout(entry._openTimer)
  clearTimeout(entry._closeTimer)
  scheduleStore.delete(jid)
  reply(
`✅ *Schedule Removed*
┏📅═══════════════════╗
┃ 🗑️ Group schedule cleared.
┃ The group will no longer
┃ auto open/close daily.
┗📅═══════════════════╝`)
}
unscheduleHandler.command = ['unschedule', 'removeschedule']
unscheduleHandler.group   = true
unscheduleHandler.admin   = true

// ── .scheduleinfo ─────────────────────────────────────────────────────────────
const scheduleinfoHandler = async ({ jid, reply }) => {
  const entry = scheduleStore.get(jid)
  if (!entry) return reply(
`📅 *No Schedule Active*\n\nSet one with:\n\`.schedule 07:00 22:00 Africa/Harare\``)

  const msO = msUntilNext(entry.openHour, entry.openMin, entry.timezone)
  const msC = msUntilNext(entry.closeHour, entry.closeMin, entry.timezone)

  reply(
`📅 *Group Schedule Info*
┏📅═══════════════════╗
┃ 🟢 Open:    *${fmtTime(entry.openHour, entry.openMin)}*
┃ 🔴 Close:   *${fmtTime(entry.closeHour, entry.closeMin)}*
┃ 🌍 Timezone: ${entry.timezone}
╠═══════════════════╣
┃ ⏳ Next open in:  ~${Math.round(msO/60000)}m
┃ ⏳ Next close in: ~${Math.round(msC/60000)}m
╠═══════════════════╣
┃ 💬 Open msg:  ${entry.openMsg ? '✅ Custom set' : '🔧 Default'}
┃ 💬 Close msg: ${entry.closeMsg ? '✅ Custom set' : '🔧 Default'}
┗📅═══════════════════╝`)
}
scheduleinfoHandler.command = ['scheduleinfo', 'groupschedule']
scheduleinfoHandler.group   = true

// ── .opengroup / .closegroup (manual instant) ─────────────────────────────────
const opengroupHandler = async ({ conn, jid, reply, isAdmin, isBotAdmin }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  if (!isBotAdmin) return reply('👑 Make me an admin first!')
  await conn.groupSettingUpdate(jid, 'not_announcement')
  await sendOpenAnnouncement(conn, jid)
}
opengroupHandler.command = ['opengroup', 'open']
opengroupHandler.group   = true
opengroupHandler.admin   = true

const closegroupHandler = async ({ conn, jid, reply, isAdmin, isBotAdmin }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  if (!isBotAdmin) return reply('👑 Make me an admin first!')
  await conn.groupSettingUpdate(jid, 'announcement')
  await sendCloseAnnouncement(conn, jid)
}
closegroupHandler.command = ['closegroup', 'close']
closegroupHandler.group   = true
closegroupHandler.admin   = true

module.exports = Object.assign(
  [scheduleHandler, setopenmsgHandler, setclosemsgHandler, unscheduleHandler,
   scheduleinfoHandler, opengroupHandler, closegroupHandler],
  { scheduleStore, scheduleGroup }
)
