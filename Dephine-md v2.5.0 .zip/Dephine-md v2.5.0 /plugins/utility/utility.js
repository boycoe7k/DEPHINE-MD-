// ╔══════════════════════════════════════════════╗
// ║   DEPHINE-MD — UTILITY TOOLS PLUGIN          ║
// ║   .time .date .calc .timer .countdown        ║
// ║   .weather2 .currency .age .days .stopwatch  ║
// ╚══════════════════════════════════════════════╝

const axios = require('axios')

// ── .time ─────────────────────────────────────────────────────────────────────
const timeHandler = async ({ reply, text }) => {
  const tz = text?.trim() || 'UTC'
  try {
    const now = new Date()
    const options = {
      timeZone: tz,
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: true,
    }
    const formatted = new Intl.DateTimeFormat('en-US', options).format(now)
    reply(
`🕐 *Current Time*
┏🕐═══════════════════╗
┃ 🌍 Timezone: ${tz}
╠═══════════════════╣
┃ ${formatted}
┗🕐═══════════════════╝

_Use_ \`.time Africa/Harare\` _for a specific timezone._`)
  } catch {
    reply(`❌ Unknown timezone: *${tz}*\nExample: \`.time America/New_York\`\n\`.time Africa/Harare\`\n\`.time Europe/London\``)
  }
}
timeHandler.command = ['time']

// ── .date ─────────────────────────────────────────────────────────────────────
const dateHandler = async ({ reply, text }) => {
  const tz  = text?.trim() || 'UTC'
  try {
    const now = new Date()
    const day  = new Intl.DateTimeFormat('en-US',{weekday:'long',timeZone:tz}).format(now)
    const date = new Intl.DateTimeFormat('en-US',{day:'numeric',month:'long',year:'numeric',timeZone:tz}).format(now)
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
    const todayIdx = new Date(new Intl.DateTimeFormat('en-US',{timeZone:tz}).format(now)).getDay()
    const remaining = days.length - 1 - todayIdx

    reply(
`📅 *Today's Date*
┏📅═══════════════════╗
┃ 📆 ${date}
┃ 📌 ${day}
┃ 🌍 Zone: ${tz}
╠═══════════════════╣
┃ 📊 Day ${todayIdx + 1} of week
┃ ⏳ ${remaining} days left in week
┃ 📅 Week ${Math.ceil(now.getDate()/7)} of month
┗📅═══════════════════╝`)
  } catch {
    reply(`❌ Unknown timezone: *${tz}*`)
  }
}
dateHandler.command = ['date']

// ── .calc ─────────────────────────────────────────────────────────────────────
const calcHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ *Usage:* `.calc <expression>`\nExample: `.calc 25 * 4 + 10 / 2`')

  // Safe math evaluator — no eval()
  try {
    const sanitized = text.replace(/[^0-9+\-*/().% ]/g, '').trim()
    if (!sanitized) throw new Error('Invalid expression')

    // Use Function constructor scoped to math only
    const result = Function('"use strict"; return (' + sanitized + ')')()

    if (!isFinite(result)) throw new Error('Result is not finite')

    reply(
`🧮 *Calculator*
┏🧮═══════════════════╗
┃ 📝 Expression:
┃ ${text}
╠═══════════════════╣
┃ ✅ Result:
┃ *${result}*
┗🧮═══════════════════╝`)
  } catch (e) {
    reply(`❌ Invalid expression: \`${text}\`\n\nExample: \`.calc 100 / 4 * 3\``)
  }
}
calcHandler.command = ['calc', 'calculate', 'math']

// ── .timer ────────────────────────────────────────────────────────────────────
// In-memory timers: sender => { endsAt, label, timeout }
const activeTimers = new Map()

const timerHandler = async ({ reply, sender, args, conn, jid }) => {
  const raw   = args[0]
  const label = args.slice(1).join(' ') || 'Timer'
  if (!raw) return reply('❓ *Usage:* `.timer <duration> [label]`\nFormats: `30s` `5m` `2h`\nExample: `.timer 5m Take medicine`')

  const match = raw.match(/^(\d+)(s|m|h)$/)
  if (!match) return reply('❌ Use format: `30s` `5m` `2h`')

  const val  = parseInt(match[1])
  const unit = match[2]
  const ms   = unit === 's' ? val * 1000 : unit === 'm' ? val * 60000 : val * 3600000
  const max  = 3 * 3600000 // 3 hour cap

  if (ms > max) return reply('❌ Max timer is 3 hours.')

  // Clear existing
  if (activeTimers.has(sender)) {
    clearTimeout(activeTimers.get(sender).timeout)
  }

  const display = unit === 's' ? `${val}s` : unit === 'm' ? `${val}m` : `${val}h`
  reply(`⏱️ *Timer set!* _${label}_ — *${display}*\n\nI'll ping you when it's done! 🌸`)

  const timeout = setTimeout(async () => {
    activeTimers.delete(sender)
    await conn.sendMessage(jid,
      require('../../utils/channelForward').withChannelForward({
        text: `⏰ *TIMER DONE!*\n\n🌸 _${label}_ — *${display}* has elapsed!\n\n_Set by:_ @${sender.split('@')[0]}`
      })
    )
  }, ms)

  activeTimers.set(sender, { endsAt: Date.now() + ms, label, timeout })
}
timerHandler.command = ['timer', 'remind']

// ── .countdown ────────────────────────────────────────────────────────────────
const countdownHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ *Usage:* `.countdown <YYYY-MM-DD>` or `.countdown <YYYY-MM-DD HH:MM>`\nExample: `.countdown 2025-12-31`')

  try {
    const target = new Date(text)
    if (isNaN(target)) throw new Error('Invalid date')

    const now  = new Date()
    const diff = target - now

    if (diff < 0) return reply(`❌ That date has already passed!\n_(${text})_`)

    const days    = Math.floor(diff / 86400000)
    const hours   = Math.floor((diff % 86400000) / 3600000)
    const minutes = Math.floor((diff % 3600000) / 60000)
    const seconds = Math.floor((diff % 60000) / 1000)

    reply(
`⏳ *Countdown*
┏⏳═══════════════════╗
┃ 🎯 Target: ${target.toDateString()}
╠═══════════════════╣
┃ 📆 ${days} days
┃ 🕐 ${hours} hours
┃ ⏱️  ${minutes} minutes
┃ ⚡ ${seconds} seconds
╠═══════════════════╣
┃ Total: ~${Math.floor(diff/3600000)}h remaining
┗⏳═══════════════════╝`)
  } catch {
    reply('❌ Invalid date format.\nExample: `.countdown 2025-12-25`')
  }
}
countdownHandler.command = ['countdown']

// ── .age ──────────────────────────────────────────────────────────────────────
const ageHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ *Usage:* `.age <YYYY-MM-DD>`\nExample: `.age 2000-06-15`')
  try {
    const dob  = new Date(text)
    if (isNaN(dob)) throw new Error()
    const now  = new Date()
    let   age  = now.getFullYear() - dob.getFullYear()
    const m    = now.getMonth() - dob.getMonth()
    if (m < 0 || (m === 0 && now.getDate() < dob.getDate())) age--

    const next = new Date(dob)
    next.setFullYear(now.getFullYear() + (now > new Date(now.getFullYear(), dob.getMonth(), dob.getDate()) ? 1 : 0))
    const daysLeft = Math.ceil((next - now) / 86400000)

    reply(
`🎂 *Age Calculator*
┏🎂═══════════════════╗
┃ 🗓️  DOB: ${dob.toDateString()}
╠═══════════════════╣
┃ 🎉 Age: *${age} years old*
┃ 📆 Born: ${dob.toLocaleDateString('en-US',{weekday:'long'})}
┃ 🎂 Next birthday in ${daysLeft} days
┗🎂═══════════════════╝`)
  } catch {
    reply('❌ Invalid date. Use: `.age 1998-04-20`')
  }
}
ageHandler.command = ['age']

// ── .days ─────────────────────────────────────────────────────────────────────
const daysHandler = async ({ reply, args }) => {
  if (args.length < 2) return reply('❓ *Usage:* `.days <date1> <date2>`\nExample: `.days 2024-01-01 2025-01-01`')
  try {
    const d1   = new Date(args[0])
    const d2   = new Date(args[1])
    if (isNaN(d1) || isNaN(d2)) throw new Error()
    const diff = Math.abs(d2 - d1)
    const days = Math.floor(diff / 86400000)
    reply(
`📏 *Days Between Dates*
┏📏═══════════════════╗
┃ 📅 From: ${d1.toDateString()}
┃ 📅 To:   ${d2.toDateString()}
╠═══════════════════╣
┃ 📆 *${days} days*
┃ 📅 ~${Math.floor(days/7)} weeks
┃ 📆 ~${(days/30).toFixed(1)} months
┃ 📅 ~${(days/365).toFixed(2)} years
┗📏═══════════════════╝`)
  } catch {
    reply('❌ Invalid dates. Use: `.days 2024-01-01 2025-12-31`')
  }
}
daysHandler.command = ['days', 'datecalc']

// ── .currency ─────────────────────────────────────────────────────────────────
const currencyHandler = async ({ reply, args }) => {
  if (args.length < 3) return reply('❓ *Usage:* `.currency <amount> <FROM> <TO>`\nExample: `.currency 100 USD ZWL`')
  const amount = parseFloat(args[0])
  const from   = args[1].toUpperCase()
  const to     = args[2].toUpperCase()
  if (isNaN(amount)) return reply('❌ Invalid amount.')
  try {
    const { data } = await axios.get(
      `https://api.exchangerate-api.com/v4/latest/${from}`,
      { timeout: 8000 }
    )
    const rate = data.rates[to]
    if (!rate) return reply(`❌ Currency *${to}* not found.`)
    const result = (amount * rate).toFixed(2)
    reply(
`💱 *Currency Converter*
┏💱═══════════════════╗
┃ 💰 ${amount} ${from}
╠═══════════════════╣
┃ 💵 *${result} ${to}*
┃ 📊 Rate: 1 ${from} = ${rate.toFixed(4)} ${to}
┃ 🕐 Live rate
┗💱═══════════════════╝`)
  } catch (e) {
    reply(`❌ Currency error: ${e.message}`)
  }
}
currencyHandler.command = ['currency', 'convert', 'rate']

module.exports = [
  timeHandler, dateHandler, calcHandler, timerHandler,
  countdownHandler, ageHandler, daysHandler, currencyHandler,
]
