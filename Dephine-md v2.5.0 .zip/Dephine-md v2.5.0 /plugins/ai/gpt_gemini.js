// ╔═══════════════════════╗
// ║   AI COMMANDS PLUGIN  ║
// ╚═══════════════════════╝

const OpenAI  = require('openai').default
const { GoogleGenerativeAI } = require('@google/generative-ai')
const axios   = require('axios')
const fs      = require('fs-extra')
const path    = require('path')
const config  = require('../../config/settings')

const TMP = path.join(__dirname, '../../tmp')
fs.ensureDirSync(TMP)

// ── GPT ───────────────────────────────────────────────────────────────────────
const gptHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.gpt <your prompt>`')
  if (!config.openaiKey) return reply('❌ OPENAI_KEY not set in .env')
  reply('🤖 Thinking...')
  try {
    const openai = new OpenAI({ apiKey: config.openaiKey })
    const res = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: `You are DEPHINE, an elegant and helpful AI assistant for WhatsApp. Keep replies concise and well-formatted.` },
        { role: 'user', content: text },
      ],
      max_tokens: 1000,
    })
    reply(`🤖 *DEPHINE GPT*\n\n${res.choices[0].message.content}`)
  } catch (e) {
    reply(`❌ GPT Error: ${e.message}`)
  }
}
gptHandler.command = ['gpt', 'ai', 'ask']

// ── Gemini ────────────────────────────────────────────────────────────────────
const geminiHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.gemini <your prompt>`')
  if (!config.geminiKey) return reply('❌ GEMINI_KEY not set in .env')
  reply('💫 Asking Gemini...')
  try {
    const genAI = new GoogleGenerativeAI(config.geminiKey)
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' })
    const result = await model.generateContent(text)
    reply(`💫 *DEPHINE Gemini*\n\n${result.response.text()}`)
  } catch (e) {
    reply(`❌ Gemini Error: ${e.message}`)
  }
}
geminiHandler.command = ['gemini']

// ── DALL·E / Image Gen ────────────────────────────────────────────────────────
const imagineHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.imagine <description>`')
  if (!config.openaiKey) return reply('❌ OPENAI_KEY not set in .env')
  reply('🎨 Generating image...')
  try {
    const openai = new OpenAI({ apiKey: config.openaiKey })
    const res = await openai.images.generate({
      model: 'dall-e-3',
      prompt: text,
      n: 1,
      size: '1024x1024',
    })
    const imgUrl = res.data[0].url
    const imgRes = await axios.get(imgUrl, { responseType: 'arraybuffer' })
    const out    = path.join(TMP, `img_${Date.now()}.jpg`)
    await fs.outputFile(out, imgRes.data)
    await conn.sendMessage(jid, {
      image: fs.readFileSync(out),
      caption: `🎨 *DEPHINE AI Art*\n_${text}_`,
    }, { quoted: msg })
    fs.remove(out)
  } catch (e) {
    reply(`❌ Image gen error: ${e.message}`)
  }
}
imagineHandler.command = ['imagine', 'dalle', 'flux']

module.exports = [gptHandler, geminiHandler, imagineHandler]
