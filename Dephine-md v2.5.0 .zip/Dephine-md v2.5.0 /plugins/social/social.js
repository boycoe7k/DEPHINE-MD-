// ╔══════════════════════════════════════════╗
// ║   DEPHINE-MD — SOCIAL / PROFILE PLUGIN   ║
// ║   .profile .bio .level .rank .afk        ║
// ║   .rep .achievements .card .status       ║
// ╚══════════════════════════════════════════╝

// User store: number => { bio, xp, rep, afk, afkReason, achievements[], joinedAt }
const userStore = new Map()

function getUser(num) {
  if (!userStore.has(num)) {
    userStore.set(num, {
      bio:          '✨ No bio set yet.',
      xp:           0,
      rep:          0,
      afk:          false,
      afkReason:    '',
      afkSince:     null,
      achievements: [],
      joinedAt:     Date.now(),
      msgCount:     0,
    })
  }
  return userStore.get(num)
}

function getLevel(xp) {
  return Math.floor(Math.sqrt(xp / 100)) + 1
}

function xpForNextLevel(level) {
  return Math.pow(level, 2) * 100
}

function getRank(xp) {
  if (xp < 500)   return { rank: '🌱 Newcomer',   color: 'grey' }
  if (xp < 1500)  return { rank: '🌸 Regular',     color: 'pink' }
  if (xp < 3000)  return { rank: '⭐ Active',       color: 'yellow' }
  if (xp < 6000)  return { rank: '💎 Elite',        color: 'blue' }
  if (xp < 10000) return { rank: '👑 Legend',       color: 'gold' }
  return               { rank: '🌟 DEPHINE Star',  color: 'rainbow' }
}

// Auto-add XP on every command use — call this from handler if desired
function addXP(num, amount = 10) {
  const u = getUser(num)
  u.xp       += amount
  u.msgCount += 1
  return u
}

// ── .profile ──────────────────────────────────────────────────────────────────
const profileHandler = async ({ reply, sender, msg, senderNum }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target    = mentioned[0] || sender
  const tNum      = target.split('@')[0]
  const u         = getUser(tNum)
  const level     = getLevel(u.xp)
  const { rank }  = getRank(u.xp)
  const nextXP    = xpForNextLevel(level)
  const progress  = Math.min(Math.round((u.xp / nextXP) * 10), 10)
  const bar       = '█'.repeat(progress) + '░'.repeat(10 - progress)
  const joined    = new Date(u.joinedAt).toDateString()
  const achievements = u.achievements.length ? u.achievements.join(' ') : '🔒 None yet'

  reply(
`👤 *DEPHINE PROFILE*
┏👤═══════════════════╗
┃ 📛 @${tNum}
╠═══════════════════╣
┃ 📝 Bio: ${u.bio}
╠═══════════════════╣
┃ 🏅 Rank:   ${rank}
┃ ⭐ Level:  ${level}
┃ 💫 XP:     ${u.xp} / ${nextXP}
┃ 📊 [${bar}]
╠═══════════════════╣
┃ 💬 Messages: ${u.msgCount}
┃ 👍 Reps:     ${u.rep}
┃ 🏆 Badges:   ${achievements}
╠═══════════════════╣
┃ 📅 Joined: ${joined}
┗👤═══════════════════╝`)
}
profileHandler.command = ['profile', 'me', 'card']

// ── .bio ──────────────────────────────────────────────────────────────────────
const bioHandler = async ({ reply, senderNum, text }) => {
  if (!text) return reply('❓ *Usage:* `.bio <your new bio>`\nExample: `.bio Just vibing with DEPHINE 🌸`')
  if (text.length > 100) return reply('❌ Bio too long. Max 100 characters.')

  const u = getUser(senderNum)
  u.bio   = text
  reply(
`✅ *Bio Updated!*
┏✍️═══════════════════╗
┃ 📝 New bio:
┃ _${text}_
┗✍️═══════════════════╝`)
}
bioHandler.command = ['bio', 'setbio']

// ── .level ────────────────────────────────────────────────────────────────────
const levelHandler = async ({ reply, sender, msg, senderNum }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target    = mentioned[0] || sender
  const tNum      = target.split('@')[0]
  const u         = getUser(tNum)
  const level     = getLevel(u.xp)
  const { rank }  = getRank(u.xp)
  const nextXP    = xpForNextLevel(level)
  const needed    = nextXP - u.xp
  const progress  = Math.min(Math.round((u.xp / nextXP) * 20), 20)
  const bar       = '█'.repeat(progress) + '░'.repeat(20 - progress)

  reply(
`⭐ *LEVEL INFO*
┏⭐═══════════════════╗
┃ 👤 @${tNum}
╠═══════════════════╣
┃ 🏅 Rank:  ${rank}
┃ ⭐ Level: *${level}*
┃ 💫 XP:    ${u.xp}
╠═══════════════════╣
┃ Progress to Level ${level + 1}:
┃ [${bar}]
┃ ${needed} XP needed
┗⭐═══════════════════╝

_Every command use earns XP! 💪_`)
}
levelHandler.command = ['level', 'lvl', 'xp']

// ── .rank ─────────────────────────────────────────────────────────────────────
const rankHandler = async ({ reply, jid }) => {
  // Build leaderboard from store
  const entries = [...userStore.entries()]
    .sort((a, b) => b[1].xp - a[1].xp)
    .slice(0, 10)

  if (!entries.length) return reply('📊 No users ranked yet. Start using commands to earn XP!')

  const medals = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟']
  const board  = entries.map(([num, u], i) => {
    const { rank } = getRank(u.xp)
    return `┃ ${medals[i]} @${num.slice(-6)} — ${u.xp} XP ${rank}`
  }).join('\n')

  reply(
`🏆 *DEPHINE LEADERBOARD*
┏🏆═══════════════════╗
┃ 📊 Top ${entries.length} Members
╠═══════════════════╣
${board}
┗🏆═══════════════════╝

_Use commands to earn XP & climb the ranks!_`)
}
rankHandler.command = ['rank', 'leaderboard', 'top']
rankHandler.group   = true

// ── .afk ──────────────────────────────────────────────────────────────────────
const afkHandler = async ({ reply, senderNum, text }) => {
  const u = getUser(senderNum)

  if (u.afk) {
    // Return from AFK
    const gone    = Date.now() - u.afkSince
    const minutes = Math.floor(gone / 60000)
    const hours   = Math.floor(minutes / 60)
    const display = hours > 0 ? `${hours}h ${minutes % 60}m` : `${minutes}m`
    u.afk       = false
    u.afkReason = ''
    u.afkSince  = null
    return reply(
`✅ *Welcome back!*
┏👋═══════════════════╗
┃ @${senderNum}
╠═══════════════════╣
┃ 🕐 You were AFK for: *${display}*
┗👋═══════════════════╝`)
  }

  // Set AFK
  u.afk       = true
  u.afkReason = text || 'No reason given'
  u.afkSince  = Date.now()

  reply(
`😴 *AFK Mode ON*
┏😴═══════════════════╗
┃ 👤 @${senderNum}
╠═══════════════════╣
┃ 💬 Reason: _${u.afkReason}_
╠═══════════════════╣
┃ _I'll let others know you're away._
┃ _Send any message to return._
┗😴═══════════════════╝`)
}
afkHandler.command = ['afk', 'away']

// ── .rep ──────────────────────────────────────────────────────────────────────
const repStore = new Map() // `${from}:${to}` => lastRepTime

const repHandler = async ({ reply, sender, senderNum, msg }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target    = mentioned[0]
  if (!target) return reply('❓ *Usage:* `.rep @user`\nGive reputation to someone!')
  if (target === sender) return reply('❌ You cannot rep yourself!')

  const key      = `${senderNum}:${target.split('@')[0]}`
  const lastRep  = repStore.get(key) || 0
  const cooldown = 24 * 60 * 60 * 1000 // 24h

  if (Date.now() - lastRep < cooldown) {
    const remaining = Math.ceil((cooldown - (Date.now() - lastRep)) / 3600000)
    return reply(`❌ You already repped @${target.split('@')[0]}!\nCooldown: *${remaining}h* remaining.`)
  }

  const tNum = target.split('@')[0]
  const u    = getUser(tNum)
  u.rep     += 1
  repStore.set(key, Date.now())

  reply(
`👍 *Reputation Given!*
┏👍═══════════════════╗
┃ From: @${senderNum}
┃ To:   @${tNum}
╠═══════════════════╣
┃ 💫 @${tNum} now has *${u.rep}* reps
┗👍═══════════════════╝`)
}
repHandler.command = ['rep', 'reputation']

// ── .achievements ─────────────────────────────────────────────────────────────
const achievementsHandler = async ({ reply, senderNum }) => {
  const u      = getUser(senderNum)
  const level  = getLevel(u.xp)
  const { rank } = getRank(u.xp)

  // Auto-grant achievements based on stats
  const earned = []
  if (u.msgCount >= 1)   earned.push('🌱 First Message')
  if (u.msgCount >= 50)  earned.push('💬 Chatterbox')
  if (u.msgCount >= 200) earned.push('📢 Talkative')
  if (u.rep >= 5)        earned.push('👍 Well Liked')
  if (u.rep >= 25)       earned.push('⭐ Popular')
  if (level >= 5)        earned.push('🚀 Level 5')
  if (level >= 10)       earned.push('💎 Level 10')
  if (u.xp >= 10000)    earned.push('🌟 DEPHINE Star')

  u.achievements = earned

  const list = earned.length
    ? earned.map(a => `┃ ✅ ${a}`).join('\n')
    : '┃ 🔒 No achievements yet.\n┃ Start chatting to earn badges!'

  reply(
`🏆 *YOUR ACHIEVEMENTS*
┏🏆═══════════════════╗
┃ 👤 @${senderNum}
┃ 🏅 ${rank} | ⭐ Level ${level}
╠═══════════════════╣
${list}
╠═══════════════════╣
┃ 🏅 ${earned.length} badges earned
┗🏆═══════════════════╝`)
}
achievementsHandler.command = ['achievements', 'badges', 'awards']

// Export userStore so handler.js can check AFK on mentions
module.exports = Object.assign(
  [profileHandler, bioHandler, levelHandler, rankHandler, afkHandler, repHandler, achievementsHandler],
  { userStore, getUser, addXP }
)
