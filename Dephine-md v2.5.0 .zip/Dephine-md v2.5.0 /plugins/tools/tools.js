// ╔═════════════════════╗
// ║   TOOLS PLUGIN      ║
// ╚═════════════════════╝

const axios  = require('axios')
const fs     = require('fs-extra')
const path   = require('path')

const TMP     = path.join(__dirname, '../../tmp')
const warnings = new Map() // jid:sender => count

fs.ensureDirSync(TMP)

// ── Save (forward quoted msg to DM) ──────────────────────────────────────────
const saveHandler = async ({ conn, msg, reply, sender }) => {
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
  if (!quoted) return reply('❓ Reply to a message to save it.')
  await conn.sendMessage(sender, { forward: { message: quoted, key: { fromMe: false, id: 'save', remoteJid: sender } } })
  reply('✅ Saved to your DM!')
}
saveHandler.command = ['save']

// ── Delete (bot deletes the quoted message) ───────────────────────────────────
const deleteHandler = async ({ conn, msg, reply, jid, isBotAdmin }) => {
  const ctx = msg.message?.extendedTextMessage?.contextInfo
  if (!ctx?.quotedMessage) return reply('❓ Reply to a message to delete it.')
  const key = { remoteJid: jid, fromMe: false, id: ctx.stanzaId, participant: ctx.participant }
  await conn.sendMessage(jid, { delete: key })
  reply('🗑️ Message deleted.')
}
deleteHandler.command = ['delete', 'del']
deleteHandler.admin   = true

// ── To URL (upload media to get a link) ──────────────────────────────────────
const tourlHandler = async ({ conn, msg, reply }) => {
  const media =
    msg.message?.imageMessage ||
    msg.message?.videoMessage ||
    msg.message?.audioMessage ||
    msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage

  if (!media) return reply('❓ Reply to or send a media file with `.tourl`')
  reply('⏳ Uploading...')

  const type   = media.mimetype?.split('/')[0] || 'image'
  const stream = await conn.downloadContentFromMessage(media, type)
  let buf = Buffer.alloc(0)
  for await (const chunk of stream) buf = Buffer.concat([buf, chunk])

  const { data } = await axios.post(
    'https://telegra.ph/upload',
    buf,
    { headers: { 'Content-Type': media.mimetype } }
  )
  reply(`🔗 *URL:* https://telegra.ph${data[0].src}`)
}
tourlHandler.command = ['tourl', 'upload']

// ── Warn ──────────────────────────────────────────────────────────────────────
const warnHandler = async ({ msg, reply, jid, args }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target = mentioned[0]
  if (!target) return reply('❓ Tag a user: `.warn @user <reason>`')
  const reason = args.slice(1).join(' ') || 'No reason given'
  const key    = `${jid}:${target}`
  const count  = (warnings.get(key) || 0) + 1
  warnings.set(key, count)
  reply(`⚠️ *Warning ${count}/3* issued to @${target.split('@')[0]}\n📝 Reason: ${reason}\n\n${count >= 3 ? '🚨 Max warnings reached!' : ''}`)
}
warnHandler.command = ['warn']
warnHandler.admin   = true
warnHandler.group   = true

// ── Warnings ──────────────────────────────────────────────────────────────────
const warningsHandler = async ({ msg, reply, jid }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target = mentioned[0]
  if (!target) return reply('❓ Tag a user: `.warnings @user`')
  const count = warnings.get(`${jid}:${target}`) || 0
  reply(`📋 *Warnings for @${target.split('@')[0]}:* ${count}/3`)
}
warningsHandler.command = ['warnings']
warningsHandler.group   = true

// ── Block / Unblock ───────────────────────────────────────────────────────────
const blockHandler = async ({ conn, msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  if (!mentioned[0]) return reply('❓ Tag a user: `.block @user`')
  await conn.updateBlockStatus(mentioned[0], 'block')
  reply(`🚫 @${mentioned[0].split('@')[0]} has been blocked.`)
}
blockHandler.command = ['block']
blockHandler.owner   = true

const unblockHandler = async ({ conn, msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  if (!mentioned[0]) return reply('❓ Tag a user: `.unblock @user`')
  await conn.updateBlockStatus(mentioned[0], 'unblock')
  reply(`✅ @${mentioned[0].split('@')[0]} has been unblocked.`)
}
unblockHandler.command = ['unblock']
unblockHandler.owner   = true

// ── Clear chat ────────────────────────────────────────────────────────────────
const clearHandler = async ({ reply }) => {
  reply('🗑️ Chat cleared on my end! _(You can manually clear yours too)_')
}
clearHandler.command = ['clear']

// ── Wallpaper ─────────────────────────────────────────────────────────────────
const wallpaperHandler = async ({ conn, jid, msg, reply, text }) => {
  const q = encodeURIComponent(text || 'nature landscape')
  reply('🖼️ Fetching wallpaper...')
  try {
    const { data } = await axios.get(
      `https://api.unsplash.com/photos/random?query=${q}&client_id=demo&orientation=landscape`
    )
    const url = data?.urls?.full || data?.urls?.regular
    if (!url) throw new Error('No image')
    const res = await axios.get(url, { responseType: 'arraybuffer' })
    const out = path.join(TMP, `wp_${Date.now()}.jpg`)
    await fs.outputFile(out, res.data)
    await conn.sendMessage(jid, {
      image: fs.readFileSync(out),
      caption: `🖼️ *Wallpaper* | ${text || 'nature'}\n_Via DEPHINE-MD_`,
    }, { quoted: msg })
    fs.remove(out)
  } catch {
    reply('❌ Could not fetch wallpaper. Try `.wallpaper forest` etc.')
  }
}
wallpaperHandler.command = ['wallpaper']



// ── .savecontact ──────────────────────────────────────────────────────────────
const savecontactHandler = async ({ conn, jid, msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const target = mentioned[0]
  if (!target) return reply('❓ Tag someone: `.savecontact @user`')
  const num  = target.split('@')[0]
  const vcard =
    'BEGIN:VCARD\nVERSION:3.0\n' +
    `FN:+${num}\nTEL;type=CELL;type=VOICE;waid=${num}:+${num}\n` +
    'END:VCARD'
  await conn.sendMessage(jid, {
    contacts: { displayName: `+${num}`, contacts: [{ vcard }] }
  }, { quoted: msg })
}
savecontactHandler.command = ['savecontact']

// ── .pair / .linkdevice ───────────────────────────────────────────────────────
const pairHandler = async ({ reply, text }) => {
  const number = (text || '').replace(/[^0-9]/g, '')

  if (!number) {
    return reply(
`📲 *Pair a Device*
┏🌸═══════════════════╗
┃ Usage:
╠═══════════════════╣
┃ .pair <your_number>
┃ Example:
┃ .pair 263781021754
╠═══════════════════╣
┃ Steps after getting code:
┃ 1. Open WhatsApp
┃ 2. Tap ⋮ → Linked devices
┃ 3. Tap "Link a device"
┃ 4. Tap "Use phone number"
┃ 5. Enter the 8-digit code
┗🌸═══════════════════╝

_Send your number with country code, no + or spaces._`)
  }

  if (number.length < 7 || number.length > 15) {
    return reply('❌ Invalid phone number. Include country code e.g. *263781021754*')
  }

  reply(`⏳ Generating pairing code for *+${number}*...\n_WhatsApp will notify that number._`)

  try {
    const {
      default: makeWASocket,
      useMultiFileAuthState,
    } = require('@whiskeysockets/baileys')
    const pino = require('pino')
    const fs   = require('fs-extra')
    const path = require('path')

    const tmpDir = path.join(__dirname, '../../tmp', `pair_${number}_${Date.now()}`)
    await fs.ensureDir(tmpDir)

    const { state, saveCreds } = await useMultiFileAuthState(tmpDir)

    const tmpConn = makeWASocket({
      auth:              state,
      printQRInTerminal: false,
      logger:            pino({ level: 'silent' }),
      browser:           ['DEPHINE-MD', 'Chrome', '120.0'],
    })

    tmpConn.ev.on('creds.update', saveCreds)

    await new Promise(r => setTimeout(r, 3000))

    const code = await tmpConn.requestPairingCode(number)
    const formatted = code?.match(/.{1,4}/g)?.join('-') || code

    reply(
`🔑 *Pairing Code Ready!*
┏🌸═══════════════════╗
┃ Number: +${number}
╠═══════════════════╣
┃ Code:
┃ *${formatted}*
╠═══════════════════╣
┃ How to use:
┃ 1. Open WhatsApp
┃ 2. Tap ⋮ → Linked devices
┃ 3. Tap "Link a device"
┃ 4. Tap "Use phone number"
┃ 5. Enter the code above
┗🌸═══════════════════╝

⏰ _Code expires in 60 seconds._`)

    setTimeout(async () => {
      try { tmpConn.ws?.close() } catch {}
      try { await fs.remove(tmpDir) } catch {}
    }, 65000)

  } catch (e) {
    reply(`❌ Failed to generate code: ${e.message.split('\n')[0]}\n\n_Make sure the number is registered on WhatsApp._`)
  }
}
pairHandler.command = ['pair', 'linkdevice']

// ── .boycoe ───────────────────────────────────────────────────────────────────
const boycoeHandler = async ({ conn, jid, msg, reply }) => {
  const caption =
`👨‍💻 *BOYCOE DEV*
┏👨‍💻═══════════════════╗
┃ 🌐 Developer Profile
╠═══════════════════╣
┃ ⚡ Full-Stack Engineer
┃ 🔧 Mobile & Backend Dev
┃ 🌐 Web & Bot Developer
┃ 🤖 WhatsApp Bot Architect
╠═══════════════════╣
┃♡ .apis — free APIs list
┃♡ .github — dev projects
┃♡ .repo — repositories
╠═══════════════════╣
┃ 📞 +263 781 021 754
┃ 🔗 wa.me/263781021754
┃ 📢 DEPHINE Channel:
┃ whatsapp.com/channel/
┃ 0029VbBxPYN2kNFj3I1H1e0f
┗👨‍💻═══════════════════╝

_"Building the future, one line at a time."_ ⚡`

  const { withChannelForward } = require('../../utils/channelForward')
  const fs   = require('fs-extra')
  const path = require('path')
  const img  = path.join(__dirname, '../../assets/card_boycoe.png')
  if (fs.existsSync(img)) {
    await conn.sendMessage(jid,
      withChannelForward({ image: fs.readFileSync(img), caption, mimetype: 'image/png' }),
      { quoted: msg }
    )
  } else {
    reply(caption)
  }
}
boycoeHandler.command = ['boycoe']

// ── .owner ────────────────────────────────────────────────────────────────────
const ownerInfoHandler = async ({ conn, jid, msg, reply }) => {
  const caption =
`👑 *DEPHINE OWNER*
┏👑═══════════════════╗
┃ 🌟 About The Owner
╠═══════════════════╣
┃ 💗 Elegant AI Specialist
┃ 🌸 Bot Creator & Designer
┃ ⚡ Smart WhatsApp Dev
┃ 👑 Powered by Dephine AI
╠═══════════════════╣
┃ 📞 +263 781 021 754
┃ 🔗 wa.me/263781021754
╠═══════════════════╣
┃ 📢 Official Channel:
┃ whatsapp.com/channel/
┃ 0029VbBxPYN2kNFj3I1H1e0f
┗👑═══════════════════╝

✨ _"Graceful like a queen, powerful like AI."_ ✨`

  const { withChannelForward } = require('../../utils/channelForward')
  const fs   = require('fs-extra')
  const path = require('path')
  const img  = path.join(__dirname, '../../assets/card_owner.png')
  if (fs.existsSync(img)) {
    await conn.sendMessage(jid,
      withChannelForward({ image: fs.readFileSync(img), caption, mimetype: 'image/png' }),
      { quoted: msg }
    )
  } else {
    reply(caption)
  }
}
ownerInfoHandler.command = ['owner']

// ── .apis ─────────────────────────────────────────────────────────────────────
const apisHandler = async ({ reply }) => {
  reply(
`🔌 *FREE APIs USED BY DEPHINE*
┏🌐═══════════════════╗
┃ API Directory
╠═══════════════════╣
┃♡ 🎵 lyrics.ovh — Song lyrics
┃♡ 🔍 ddg-api — Web search
┃♡ 📚 Wikipedia REST API
┃♡ 🌤️ wttr.in — Weather
┃♡ 🌐 MyMemory — Translate
┃♡ 📖 DictionaryAPI — Define
┃♡ 👨‍💻 GitHub REST API
┃♡ 📰 GNews — News headlines
┃♡ 🎲 JokeAPI — Random jokes
┃♡ 🎮 OpenTDB — Trivia
┃♡ 🖼️ Unsplash — Wallpapers
┃♡ 📷 Telegra.ph — File CDN
┃♡ 🎵 Saavn API — Music
┃♡ 🤖 OpenAI — GPT/DALL-E
┃♡ 💫 Google — Gemini AI
┃♡ 📱 Quackr — Temp numbers
┗🌐═══════════════════╝

_All APIs are integrated & working._`)
}
apisHandler.command = ['apis']

module.exports = [
  saveHandler, deleteHandler, tourlHandler,
  warnHandler, warningsHandler,
  blockHandler, unblockHandler,
  clearHandler, wallpaperHandler,
  savecontactHandler, pairHandler,
  boycoeHandler, ownerInfoHandler, apisHandler,
]
