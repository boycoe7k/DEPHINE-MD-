// ╔══════════════════════╗
// ║   OWNER MENU PLUGIN  ║
// ╚══════════════════════╝

const config = require('../../config/settings')
const { exec } = require('child_process')

// ── Broadcast ─────────────────────────────────────────────────────────────────
const broadcastHandler = async ({ conn, reply, text }) => {
  if (!text) return reply('❓ Usage: `.broadcast <message>`')
  reply('📡 Broadcasting...')
  try {
    const chats = Object.keys(await conn.getChats?.() || {})
    let sent = 0
    for (const jid of chats) {
      try {
        await conn.sendMessage(jid, {
          text: `📢 *DEPHINE Broadcast*\n\n${text}\n\n_— ${config.botName}_`
        })
        sent++
        await new Promise(r => setTimeout(r, 500)) // rate limit
      } catch (_) {}
    }
    reply(`✅ Broadcast sent to *${sent}* chats.`)
  } catch (e) {
    reply(`❌ Broadcast error: ${e.message}`)
  }
}
broadcastHandler.command = ['broadcast']
broadcastHandler.owner   = true

// ── Set Prefix ────────────────────────────────────────────────────────────────
const setprefixHandler = async ({ reply, args }) => {
  const p = args[0]
  if (!p) return reply('❓ Usage: `.setprefix /`')
  config.prefix = p
  reply(`✅ Prefix changed to: *${p}*\n_Example: ${p}ping_`)
}
setprefixHandler.command = ['setprefix']
setprefixHandler.owner   = true

// ── Restart ───────────────────────────────────────────────────────────────────
const restartHandler = async ({ reply }) => {
  reply('🔄 Restarting DEPHINE-MD...')
  setTimeout(() => process.exit(0), 2000) // PM2/systemd will restart
}
restartHandler.command = ['restart']
restartHandler.owner   = true

// ── Shutdown ──────────────────────────────────────────────────────────────────
const shutdownHandler = async ({ reply }) => {
  reply('🌸 Shutting down... Goodbye, darling~')
  setTimeout(() => process.exit(1), 2000)
}
shutdownHandler.command = ['shutdown']
shutdownHandler.owner   = true

// ── Eval (execute JS) ─────────────────────────────────────────────────────────
const evalHandler = async ({ conn, reply, text, jid, sender }) => {
  if (!text) return reply('❓ Usage: `.eval <js code>`')
  try {
    // Expose useful vars
    const result = await eval(`(async () => { ${text} })()`)
    const output = typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result)
    reply(`✅ *Eval Result:*\n\`\`\`\n${output?.slice(0, 1000)}\n\`\`\``)
  } catch (e) {
    reply(`❌ *Eval Error:*\n\`\`\`\n${e.message}\n\`\`\``)
  }
}
evalHandler.command = ['eval', '>']
evalHandler.owner   = true

// ── Update ────────────────────────────────────────────────────────────────────
const updateHandler = async ({ reply }) => {
  reply('🔄 Pulling latest updates from GitHub...')
  exec('git pull', (err, stdout, stderr) => {
    if (err) return reply(`❌ Update error:\n${err.message}`)
    reply(`✅ *Update result:*\n\`\`\`\n${stdout || stderr}\n\`\`\`\n\nRestart bot to apply: \`.restart\``)
  })
}
updateHandler.command = ['update']
updateHandler.owner   = true

module.exports = [broadcastHandler, setprefixHandler, restartHandler, shutdownHandler, evalHandler, updateHandler]
