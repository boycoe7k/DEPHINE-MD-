// ╔══════════════════════════════╗
// ║  YOUTUBE DOWNLOADER PLUGIN   ║
// ╚══════════════════════════════╝

const ytSearch = require('yt-search')
const ytdl     = require('@distube/ytdl-core')
const fs       = require('fs-extra')
const path     = require('path')

const TMP = path.join(__dirname, '../../tmp')
fs.ensureDirSync(TMP)

async function searchYT(query) {
  const res = await ytSearch(query)
  return res.videos[0] || null
}

const playHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.play <song title>`')
  reply('🔍 Searching YouTube...')
  try {
    const video = await searchYT(text)
    if (!video) return reply('❌ No results found.')
    if (video.duration.seconds > 600) return reply('⚠️ Song too long (max 10 min).')
    reply(`🎵 Downloading: *${video.title}*\n⏱️ ${video.timestamp}`)

    const outPath = path.join(TMP, `audio_${Date.now()}.mp3`)
    await new Promise((res, rej) => {
      const stream = ytdl(video.url, { filter: 'audioonly', quality: 'highestaudio' })
      stream.on('error', rej)
      stream.pipe(fs.createWriteStream(outPath))
        .on('finish', res)
        .on('error', rej)
    })

    await conn.sendMessage(jid, {
      audio: fs.readFileSync(outPath),
      mimetype: 'audio/mpeg',
      fileName: `${video.title}.mp3`,
    }, { quoted: msg })

    fs.remove(outPath).catch(() => {})
  } catch (e) {
    reply(`❌ Download failed: ${e.message.split('\n')[0]}`)
  }
}
playHandler.command = ['play', 'song', 'music', 'mp3', 'ytmp3']

const videoHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.video <title or url>`')
  reply('🔍 Searching...')
  try {
    let url = text
    let title = text
    if (!ytdl.validateURL(text)) {
      const video = await searchYT(text)
      if (!video) return reply('❌ No results found.')
      url = video.url
      title = video.title
      reply(`🎬 Downloading: *${video.title}*`)
    }

    const info = await ytdl.getInfo(url)
    const fmt  = ytdl.chooseFormat(info.formats, { quality: 'highestvideo', filter: 'videoandaudio' })
    if (!fmt) return reply('❌ No downloadable format found.')

    const outPath = path.join(TMP, `video_${Date.now()}.mp4`)
    await new Promise((res, rej) => {
      const stream = ytdl(url, { format: fmt })
      stream.on('error', rej)
      stream.pipe(fs.createWriteStream(outPath))
        .on('finish', res)
        .on('error', rej)
    })

    await conn.sendMessage(jid, {
      video: fs.readFileSync(outPath),
      caption: `🎬 ${info.videoDetails.title}`,
      mimetype: 'video/mp4',
    }, { quoted: msg })

    fs.remove(outPath).catch(() => {})
  } catch (e) {
    reply(`❌ Download failed: ${e.message.split('\n')[0]}`)
  }
}
videoHandler.command = ['video', 'ytmp4']

const ytsHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.yts <query>`')
  reply('🔍 Searching YouTube...')
  const res = await ytSearch(text)
  const top = res.videos.slice(0, 5)
  if (!top.length) return reply('❌ No results found.')

  let msg = `🎵 *YouTube Results for:* _${text}_\n\n`
  top.forEach((v, i) => {
    msg += `*${i + 1}.* ${v.title}\n`
    msg += `    ⏱️ ${v.timestamp} | 👁️ ${v.views}\n`
    msg += `    🔗 ${v.url}\n\n`
  })
  reply(msg.trim())
}
ytsHandler.command = ['yts']

module.exports = [playHandler, videoHandler, ytsHandler]
