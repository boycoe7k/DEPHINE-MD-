// ╔══════════════════════════════════╗
// ║  SOCIAL MEDIA DOWNLOADER PLUGIN  ║
// ╚══════════════════════════════════╝

const axios = require('axios')
const fs    = require('fs-extra')
const path  = require('path')

const TMP = path.join(__dirname, '../../tmp')
fs.ensureDirSync(TMP)

async function downloadFile(url, dest) {
  const res = await axios({ url, responseType: 'arraybuffer' })
  await fs.outputFile(dest, res.data)
}

// ── TikTok ────────────────────────────────────────────────────────────────────
const tiktokHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.tiktok <url>`')
  reply('⏳ Downloading TikTok video...')
  try {
    const api = `https://api.tikmate.app/api/lookup?url=${encodeURIComponent(text)}`
    const { data } = await axios.get(api)
    if (!data?.token) throw new Error('Could not fetch video')

    const dlUrl = `https://tikmate.app/download/${data.token}/${data.id}.mp4`
    const out   = path.join(TMP, `tt_${Date.now()}.mp4`)
    await downloadFile(dlUrl, out)

    await conn.sendMessage(jid, {
      video: fs.readFileSync(out),
      caption: '🎵 TikTok via DEPHINE-MD',
      mimetype: 'video/mp4',
    }, { quoted: msg })

    fs.remove(out)
  } catch (e) {
    reply(`❌ Failed: ${e.message}`)
  }
}
tiktokHandler.command = ['tiktok']

// ── Instagram ─────────────────────────────────────────────────────────────────
const instagramHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.instagram <url>`')
  reply('⏳ Fetching Instagram media...')
  try {
    const { data } = await axios.get(
      `https://instagram-downloader-download-instagram-videos-stories.p.rapidapi.com/index?url=${encodeURIComponent(text)}`,
      { headers: { 'X-RapidAPI-Host': 'instagram-downloader-download-instagram-videos-stories.p.rapidapi.com' } }
    )
    const url = data?.media?.[0]?.url
    if (!url) throw new Error('No media found')

    const out = path.join(TMP, `ig_${Date.now()}.mp4`)
    await downloadFile(url, out)
    await conn.sendMessage(jid, {
      video: fs.readFileSync(out),
      caption: '📸 Instagram via DEPHINE-MD',
      mimetype: 'video/mp4',
    }, { quoted: msg })
    fs.remove(out)
  } catch (e) {
    reply(`❌ Failed: ${e.message}`)
  }
}
instagramHandler.command = ['instagram', 'ig']

// ── Facebook ──────────────────────────────────────────────────────────────────
const facebookHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.facebook <url>`')
  reply('⏳ Fetching Facebook video...')
  try {
    const { data } = await axios.get(
      `https://facebook-video-downloader6.p.rapidapi.com/fbdown/home?url=${encodeURIComponent(text)}`,
      { headers: { 'X-RapidAPI-Host': 'facebook-video-downloader6.p.rapidapi.com' } }
    )
    const url = data?.hd || data?.sd
    if (!url) throw new Error('No video found')

    const out = path.join(TMP, `fb_${Date.now()}.mp4`)
    await downloadFile(url, out)
    await conn.sendMessage(jid, {
      video: fs.readFileSync(out),
      caption: '📘 Facebook via DEPHINE-MD',
      mimetype: 'video/mp4',
    }, { quoted: msg })
    fs.remove(out)
  } catch (e) {
    reply(`❌ Failed: ${e.message}`)
  }
}
facebookHandler.command = ['facebook', 'fb']

module.exports = [tiktokHandler, instagramHandler, facebookHandler]
