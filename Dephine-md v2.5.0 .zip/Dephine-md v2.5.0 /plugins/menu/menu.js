const { withChannelForward } = require('../../utils/channelForward')
const config = require('../../config/settings')

function buildMenuText() {
  return `┏♡═══════════════════♡┓
🌸 *${config.botName}* 🌸
_Elegant • Smart • Powerful_
┗♡═══════════════════♡┛

┏💗═══════════════════╗
┃ 👑 *DEPHINE GROUP MANAGER*
╠═══════════════════╣
┃♡ .ban
┃♡ .unban
┃♡ .promote
┃♡ .demote
┃♡ .mute
┃♡ .unmute
┃♡ .kick
┃♡ .slowmode
┃♡ .lockgroup
┃♡ .unlockgroup
┃♡ .setname
┃♡ .setdesc
┃♡ .revoke
┃♡ .resetlink
┃♡ .creategc
┃♡ .leavegc
┃♡ .welcome
┃♡ .goodbye
┗💗═══════════════════╝

┏📅═══════════════════╗
┃ ⏰ *DEPHINE SCHEDULER*
╠═══════════════════╣
┃♡ .schedule
┃♡ .unschedule
┃♡ .scheduleinfo
┃♡ .opengroup
┃♡ .closegroup
┃♡ .setopenmsg
┃♡ .setclosemsg
┗📅═══════════════════╝

┏✨═══════════════════╗
┃ ⚙️ *DEPHINE SETTINGS*
╠═══════════════════╣
┃♡ .mode
┃♡ .autostatus
┃♡ .clearsession
┃♡ .cleartmp
┃♡ .setpp
┃♡ .autoreact
┃♡ .setbotbio
┃♡ .autotyping
┃♡ .autorecording
┗✨═══════════════════╝

┏🎀═══════════════════╗
┃ 📥 *DEPHINE DOWNLOADER*
╠═══════════════════╣
┃♡ .play
┃♡ .song
┃♡ .music
┃♡ .mp3
┃♡ .ytmp3
┃♡ .yts
┃♡ .video
┃♡ .ytmp4
┃♡ .instagram
┃♡ .facebook
┃♡ .tiktok
┗🎀═══════════════════╝

┏🌸═══════════════════╗
┃ 🛠 *DEPHINE TOOLS*
╠═══════════════════╣
┃♡ .save
┃♡ .savecontact
┃♡ .block
┃♡ .unblock
┃♡ .pair
┃♡ .linkdevice
┃♡ .delete
┃♡ .tourl
┃♡ .upload
┃♡ .clear
┃♡ .warnings
┃♡ .warn
┃♡ .boycoe
┃♡ .owner
┃♡ .apis
┗🌸═══════════════════╝

┏📱═══════════════════╗
┃ 🔢 *DEPHINE TEMP NUMBERS*
╠═══════════════════╣
┃♡ .temp
┃♡ .countries
┃♡ .buy
┃♡ .otp
┃♡ .tget
┃♡ .cancel
┗📱═══════════════════╝

┏📊═══════════════════╗
┃ 📈 *DEPHINE STATS*
╠═══════════════════╣
┃♡ .ping
┃♡ .uptime
┃♡ .runtime
┃♡ .users
┃♡ .groups
┃♡ .botinfo
┃♡ .commands
┃♡ .speed
┗📊═══════════════════╝

┏🎵═══════════════════╗
┃ 🎶 *DEPHINE MUSIC*
╠═══════════════════╣
┃♡ .lyrics
┃♡ .spotify
┃♡ .playlist
┃♡ .nowplaying
┃♡ .artist
┃♡ .album
┃♡ .soundcloud
┃♡ .audiomack
┗🎵═══════════════════╝

┏🔎═══════════════════╗
┃ 🌐 *DEPHINE SEARCH*
╠═══════════════════╣
┃♡ .google
┃♡ .image
┃♡ .wiki
┃♡ .news
┃♡ .weather
┃♡ .translate
┃♡ .define
┃♡ .githubsearch
┗🔎═══════════════════╝

┏💫═══════════════════╗
┃ 🤖 *DEPHINE AI MENU*
╠═══════════════════╣
┃♡ .gpt
┃♡ .gemini
┃♡ .imagine
┃♡ .flux
┃♡ .dalle
┗💫═══════════════════╝

┏🎲═══════════════════╗
┃ 🎮 *DEPHINE FUN ZONE*
╠═══════════════════╣
┃♡ .dice
┃♡ .coin
┃♡ .random
┃♡ .pick
┃♡ .riddle
┃♡ .joke
┃♡ .8ball
┃♡ .truth
┃♡ .dare
┃♡ .trivia
┗🎲═══════════════════╝

┏💖═══════════════════╗
┃ 💕 *DEPHINE LOVE MENU*
╠═══════════════════╣
┃♡ .compliment
┃♡ .flirt
┃♡ .ship
┃♡ .simp
┃♡ .goodnight
┃♡ .lovenight
┃♡ .shayari
┗💖═══════════════════╝

┏🔮═══════════════════╗
┃ 🎨 *DEPHINE DESIGN MENU*
╠═══════════════════╣
┃♡ .metallic
┃♡ .ice
┃♡ .snow
┃♡ .matrix
┃♡ .neon
┃♡ .purple
┃♡ .glitch
┃♡ .fire
┗🔮═══════════════════╝

┏🔐═══════════════════╗
┃ 🔒 *DEPHINE CRYPTO TOOLS*
╠═══════════════════╣
┃♡ .encode
┃♡ .decode
┃♡ .hash
┃♡ .qr
┃♡ .password
┃♡ .uuid
┃♡ .reverse
┃♡ .binary
┗🔐═══════════════════╝

┏📅═══════════════════╗
┃ 🛠️ *DEPHINE UTILITY TOOLS*
╠═══════════════════╣
┃♡ .time
┃♡ .date
┃♡ .calc
┃♡ .timer
┃♡ .countdown
┃♡ .age
┃♡ .days
┃♡ .currency
┗📅═══════════════════╝

┏🗳️═══════════════════╗
┃ 📊 *DEPHINE POLLS & VOTING*
╠═══════════════════╣
┃♡ .poll
┃♡ .vote
┃♡ .endpoll
┃♡ .pollresult
┃♡ .quickvote
┗🗳️═══════════════════╝

┏🤝═══════════════════╗
┃ 👤 *DEPHINE SOCIAL & PROFILE*
╠═══════════════════╣
┃♡ .profile
┃♡ .bio
┃♡ .level
┃♡ .rank
┃♡ .afk
┃♡ .rep
┃♡ .achievements
┗🤝═══════════════════╝

┏🎙️═══════════════════╗
┃ 🎤 *DEPHINE VOICE MESSAGES*
╠═══════════════════╣
┃♡ .tts
┃♡ .voicegreeting
┃♡ .voicelove
┃♡ .voicemotivation
┃♡ .voicejoke
┃♡ .voicebotinfo
┃♡ .voiceweather
┃♡ .voicenews
┗🎙️═══════════════════╝

┏💬═══════════════════╗
┃ ✨ *DEPHINE SMART TRIGGERS*
╠═══════════════════╣
┃♡ .addtrigger
┃♡ .deltrigger
┃♡ .triggers
┃ 🌸 Say "Dephine" anytime!
┃ 💗 Mood detection active
┃ 🌅 Greeting detection active
┗💬═══════════════════╝

┏👑═══════════════════╗
┃ 🧠 *DEPHINE OWNER MENU*
╠═══════════════════╣
┃♡ .broadcast
┃♡ .setprefix
┃♡ .restart
┃♡ .shutdown
┃♡ .eval
┃♡ .update
┗👑═══════════════════╝

┏👑═══════════════════╗
┃ 🌟 *ABOUT DEPHINE*
╠═══════════════════╣
┃ 💗 Elegant AI Assistant
┃ ⚡ Smart WhatsApp Bot
┃ 👑  𖤍 𝙥𝙤𝙬𝙚𝙧𝙚𝙙 𝙗𝙮 𝘽𝙊𝙔𝘾𝙊𝙀 𖤍
┃ 📞 Owner: +${config.ownerNum}
┗👑═══════════════════╝

✨ _">  𖤍 𝙥𝙤𝙬𝙚𝙧𝙚𝙙 𝙗𝙮 𝘽𝙊𝙔𝘾𝙊𝙀 𖤍."_ ✨`
}

// ── Welcome voice greetings pool ─────────────────────────────────────────────
const WELCOME_VOICES = [
  `Welcome to DEPHINE! I am your elegant and powerful WhatsApp assistant. Type dot menu to explore over two hundred commands. I am here for you twenty four seven. Let's have an amazing time together!`,
  `Hey there beautiful! DEPHINE here, your smart and elegant WhatsApp bot. I can help you download music, chat with AI, manage your group, play games, and so much more. Just type dot menu to get started!`,
  `Hello and welcome! This is DEPHINE speaking. I am graceful like a queen and powerful like AI. Whether you need music, AI assistance, group tools or just some fun, I have got you covered! Type dot menu to see everything!`,
  `Good day gorgeous! DEPHINE is online and ready to serve you. From YouTube downloads to GPT conversations, polls, voice messages, and two hundred plus commands, I do it all. Welcome to the DEPHINE experience!`,
  `Welcome, darling! I am DEPHINE, your personal WhatsApp assistant. Powered by cutting edge AI and built with love by Boycoe Dev. I am so excited to meet you! Type dot menu to discover what I can do for you today!`,
]

const menuHandler = async ({ conn, jid, msg, senderNum }) => {
  const fsLib   = require('fs-extra')
  const pathLib = require('path')
  const axios   = require('axios')
  const text    = buildMenuText()

  // ── 1. Send welcome voice note first ────────────────────────────────────────
  try {
    const voiceText = WELCOME_VOICES[Math.floor(Math.random() * WELCOME_VOICES.length)]
    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(voiceText)}&tl=en&client=tw-ob`
    const res    = await axios.get(ttsUrl, {
      responseType: 'arraybuffer',
      timeout: 12000,
      headers: { 'User-Agent': 'Mozilla/5.0' },
    })
    const tmpPath = pathLib.join(__dirname, '../../tmp', `menu_voice_${Date.now()}.ogg`)
    await fsLib.outputFile(tmpPath, Buffer.from(res.data))
    await conn.sendMessage(jid,
      withChannelForward({
        audio: fsLib.readFileSync(tmpPath),
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true,
      }),
      { quoted: msg }
    )
    fsLib.remove(tmpPath)
  } catch (_) {
    // Voice failed silently — menu still sends
  }

  // ── 2. Send menu image + text ────────────────────────────────────────────────
  const imgPath = pathLib.join(__dirname, '../../assets/menu.png')
  if (fsLib.existsSync(imgPath)) {
    await conn.sendMessage(jid,
      withChannelForward({ image: fsLib.readFileSync(imgPath), caption: text, mimetype: 'image/png' }),
      { quoted: msg }
    )
  } else {
    // No custom menu.png found — send text only
    await conn.sendMessage(jid, withChannelForward({ text }), { quoted: msg })
  }
}
menuHandler.command = ['menu', 'help', 'start']
module.exports = menuHandler
