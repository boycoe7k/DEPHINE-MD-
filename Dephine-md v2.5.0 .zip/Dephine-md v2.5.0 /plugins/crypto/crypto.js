// ╔══════════════════════════════════════════╗
// ║   DEPHINE-MD — ENCRYPTION / HASH TOOLS  ║
// ║   .encode .decode .hash .qr .binary      ║
// ║   .hex .reverse .password .uuid          ║
// ╚══════════════════════════════════════════╝

const crypto = require('crypto')

// ── .encode ───────────────────────────────────────────────────────────────────
const encodeHandler = async ({ reply, args, text }) => {
  const type = args[0]?.toLowerCase()
  const input = args.slice(1).join(' ')
  if (!type || !input) return reply(
`❓ *Usage:* \`.encode <type> <text>\`

Types: \`base64\` \`hex\` \`url\` \`binary\`

Example: \`.encode base64 Hello World\``)

  let result
  try {
    switch (type) {
      case 'base64':  result = Buffer.from(input).toString('base64'); break
      case 'hex':     result = Buffer.from(input).toString('hex'); break
      case 'url':     result = encodeURIComponent(input); break
      case 'binary':  result = input.split('').map(c => c.charCodeAt(0).toString(2).padStart(8,'0')).join(' '); break
      default: return reply(`❌ Unknown type: *${type}*\nUse: base64 | hex | url | binary`)
    }
    reply(
`🔐 *Encoded (${type.toUpperCase()})*
┏🔐═══════════════════╗
┃ Input:  ${input.slice(0,40)}${input.length>40?'...':''}
╠═══════════════════╣
┃ Output:
┗🔐═══════════════════╝

\`\`\`${result}\`\`\``)
  } catch (e) {
    reply(`❌ Encode error: ${e.message}`)
  }
}
encodeHandler.command = ['encode']

// ── .decode ───────────────────────────────────────────────────────────────────
const decodeHandler = async ({ reply, args }) => {
  const type = args[0]?.toLowerCase()
  const input = args.slice(1).join(' ')
  if (!type || !input) return reply(
`❓ *Usage:* \`.decode <type> <text>\`

Types: \`base64\` \`hex\` \`url\` \`binary\`

Example: \`.decode base64 SGVsbG8gV29ybGQ=\``)

  let result
  try {
    switch (type) {
      case 'base64':  result = Buffer.from(input, 'base64').toString('utf8'); break
      case 'hex':     result = Buffer.from(input, 'hex').toString('utf8'); break
      case 'url':     result = decodeURIComponent(input); break
      case 'binary':  result = input.split(' ').map(b => String.fromCharCode(parseInt(b,2))).join(''); break
      default: return reply(`❌ Unknown type: *${type}*\nUse: base64 | hex | url | binary`)
    }
    reply(
`🔓 *Decoded (${type.toUpperCase()})*
┏🔓═══════════════════╗
┃ Input:  ${input.slice(0,40)}${input.length>40?'...':''}
╠═══════════════════╣
┃ Output:
┗🔓═══════════════════╝

\`\`\`${result}\`\`\``)
  } catch (e) {
    reply(`❌ Decode error: ${e.message}`)
  }
}
decodeHandler.command = ['decode']

// ── .hash ─────────────────────────────────────────────────────────────────────
const hashHandler = async ({ reply, args }) => {
  const algo  = args[0]?.toLowerCase()
  const input = args.slice(1).join(' ')
  const algos = ['md5','sha1','sha256','sha512','sha224','sha384']

  if (!algo || !input) return reply(
`❓ *Usage:* \`.hash <algorithm> <text>\`

Algorithms: \`md5\` \`sha1\` \`sha256\` \`sha512\`

Example: \`.hash sha256 password123\``)

  if (!algos.includes(algo)) return reply(`❌ Unknown algorithm: *${algo}*\nAvailable: ${algos.join(', ')}`)

  try {
    const hash = crypto.createHash(algo).update(input).digest('hex')
    reply(
`#️⃣ *Hash (${algo.toUpperCase()})*
┏#️⃣═══════════════════╗
┃ Input: ${input.slice(0,35)}${input.length>35?'...':''}
┃ Algo:  ${algo.toUpperCase()}
╠═══════════════════╣
┃ Hash:
┗#️⃣═══════════════════╝

\`\`\`${hash}\`\`\`

_Length: ${hash.length} chars_`)
  } catch (e) {
    reply(`❌ Hash error: ${e.message}`)
  }
}
hashHandler.command = ['hash']

// ── .qr ───────────────────────────────────────────────────────────────────────
const qrHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ *Usage:* `.qr <text or URL>`\nExample: `.qr https://whatsapp.com`')
  reply('⏳ Generating QR code...')
  try {
    const axios = require('axios')
    const url   = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(text)}&color=c4516a&bgcolor=0a0608`
    const res   = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 })
    await conn.sendMessage(jid,
      require('../../utils/channelForward').withChannelForward({
        image:   Buffer.from(res.data),
        caption: `🔲 *QR Code*\n\n📝 Data: ${text.slice(0,60)}${text.length>60?'...':''}\n\n_Scan with any QR reader_`,
        mimetype:'image/png',
      }),
      { quoted: msg }
    )
  } catch (e) {
    reply(`❌ QR generation failed: ${e.message}`)
  }
}
qrHandler.command = ['qr', 'qrcode']

// ── .password ─────────────────────────────────────────────────────────────────
const passwordHandler = async ({ reply, args }) => {
  const len = Math.min(Math.max(parseInt(args[0]) || 16, 6), 64)
  const sets = {
    upper:   'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    lower:   'abcdefghijklmnopqrstuvwxyz',
    digits:  '0123456789',
    special: '!@#$%^&*()_+-=[]{}|;:,.<>?',
  }
  const pool = Object.values(sets).join('')
  const pwd  = Array.from({ length: len }, () => pool[crypto.randomInt(pool.length)]).join('')
  const strength = len < 10 ? '🔴 Weak' : len < 16 ? '🟡 Medium' : '🟢 Strong'

  reply(
`🔑 *Password Generator*
┏🔑═══════════════════╗
┃ Length:   ${len} chars
┃ Strength: ${strength}
╠═══════════════════╣
┃ Password:
┗🔑═══════════════════╝

\`\`\`${pwd}\`\`\`

_Uppercase ✅ Lowercase ✅ Numbers ✅ Symbols ✅_`)
}
passwordHandler.command = ['password', 'genpass', 'passgen']

// ── .uuid ─────────────────────────────────────────────────────────────────────
const uuidHandler = async ({ reply, args }) => {
  const count = Math.min(parseInt(args[0]) || 1, 10)
  const uuids = Array.from({ length: count }, () => crypto.randomUUID())
  reply(
`🆔 *UUID Generator*
┏🆔═══════════════════╗
┃ Generated: ${count} UUID(s)
╠═══════════════════╣
${uuids.map((u,i) => `┃ ${i+1}. \`${u}\``).join('\n')}
┗🆔═══════════════════╝`)
}
uuidHandler.command = ['uuid']

// ── .reverse ──────────────────────────────────────────────────────────────────
const reverseHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.reverse <text>`')
  reply(`🔄 *Reversed:*\n\n\`\`\`${text.split('').reverse().join('')}\`\`\``)
}
reverseHandler.command = ['reverse']

// ── .binary ───────────────────────────────────────────────────────────────────
const binaryHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.binary <text>`')
  const bin = text.split('').map(c => c.charCodeAt(0).toString(2).padStart(8,'0')).join(' ')
  reply(
`💾 *Binary Converter*
┏💾═══════════════════╗
┃ Text: ${text.slice(0,30)}
╠═══════════════════╣
┃ Binary:
┗💾═══════════════════╝

\`\`\`${bin}\`\`\``)
}
binaryHandler.command = ['binary', 'bin2text']

module.exports = [
  encodeHandler, decodeHandler, hashHandler, qrHandler,
  passwordHandler, uuidHandler, reverseHandler, binaryHandler,
]
