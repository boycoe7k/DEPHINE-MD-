// ╔══════════════════════════════════════════╗
// ║   DEPHINE-MD — POLLS & VOTING PLUGIN     ║
// ║   .poll .vote .endpoll .pollresult       ║
// ║   .quickvote .strawpoll                  ║
// ╚══════════════════════════════════════════╝

// Poll store: jid => { question, options[], votes{}, creator, createdAt, active }
const pollStore = new Map()

// ── .poll ─────────────────────────────────────────────────────────────────────
const pollHandler = async ({ reply, jid, sender, text }) => {
  if (!text) return reply(
`❓ *Usage:* \`.poll <question> | <option1> | <option2> | ...\`

Example:
\`.poll Best fruit? | Apple | Mango | Orange | Banana\`

_Minimum 2 options, maximum 8 options._`)

  const parts = text.split('|').map(s => s.trim()).filter(Boolean)
  if (parts.length < 3) return reply('❌ Need a question + at least 2 options.\nExample: `.poll Best color? | Red | Blue | Green`')
  if (parts.length > 9) return reply('❌ Maximum 8 options allowed.')

  const question = parts[0]
  const options  = parts.slice(1)

  // Close any existing poll in this chat
  pollStore.set(jid, {
    question,
    options,
    votes:     {},
    creator:   sender,
    createdAt: Date.now(),
    active:    true,
  })

  const optLines = options.map((o, i) => `┃♡ *${i+1}.* ${o}`).join('\n')
  reply(
`🗳️ *NEW POLL CREATED!*
┏🗳️═══════════════════╗
┃ ❓ ${question}
╠═══════════════════╣
${optLines}
╠═══════════════════╣
┃ 📊 0 votes so far
┃ ⏳ Poll is OPEN
┗🗳️═══════════════════╝

_Vote using_ \`.vote <number>\`
_e.g._ \`.vote 1\` _for option 1_
_Creator: @${sender.split('@')[0]}_`)
}
pollHandler.command = ['poll', 'createpoll']
pollHandler.group   = true

// ── .vote ─────────────────────────────────────────────────────────────────────
const voteHandler = async ({ reply, jid, sender, args }) => {
  const poll = pollStore.get(jid)
  if (!poll) return reply('❌ No active poll in this group.\nCreate one with `.poll`')
  if (!poll.active) return reply('❌ This poll has ended. Use `.pollresult` to see results.')

  const choice = parseInt(args[0])
  if (isNaN(choice) || choice < 1 || choice > poll.options.length) {
    return reply(`❌ Invalid choice. Vote *1* to *${poll.options.length}*.\nUse: \`.vote 2\``)
  }

  const prevVote = poll.votes[sender]
  poll.votes[sender] = choice - 1

  const totalVotes = Object.keys(poll.votes).length
  const chosen     = poll.options[choice - 1]

  reply(
`✅ *Vote Recorded!*
┏✅═══════════════════╗
┃ 🗳️ You voted for:
┃ *${choice}. ${chosen}*
╠═══════════════════╣
┃ 📊 Total votes: ${totalVotes}
┃ ${prevVote !== undefined ? '🔄 Changed your vote' : '✨ First time voting'}
┗✅═══════════════════╝

_Use_ \`.pollresult\` _to see standings._`)
}
voteHandler.command = ['vote']
voteHandler.group   = true

// ── .pollresult ───────────────────────────────────────────────────────────────
const pollresultHandler = async ({ reply, jid }) => {
  const poll = pollStore.get(jid)
  if (!poll) return reply('❌ No poll found in this group.')

  const totalVotes = Object.keys(poll.votes).length
  const counts     = new Array(poll.options.length).fill(0)

  Object.values(poll.votes).forEach(v => counts[v]++)

  const maxVotes = Math.max(...counts, 1)
  const results  = poll.options.map((opt, i) => {
    const c    = counts[i]
    const pct  = totalVotes ? Math.round((c / totalVotes) * 100) : 0
    const bar  = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10))
    const crown = c === maxVotes && c > 0 ? ' 👑' : ''
    return `┃ *${i+1}.* ${opt}${crown}\n┃ [${bar}] ${pct}% (${c})`
  }).join('\n')

  reply(
`📊 *POLL RESULTS*
┏📊═══════════════════╗
┃ ❓ ${poll.question}
╠═══════════════════╣
${results}
╠═══════════════════╣
┃ 🗳️  Total votes: *${totalVotes}*
┃ ⏳ Status: ${poll.active ? '🟢 OPEN' : '🔴 CLOSED'}
┗📊═══════════════════╝`)
}
pollresultHandler.command = ['pollresult', 'results', 'standing']
pollresultHandler.group   = true

// ── .endpoll ──────────────────────────────────────────────────────────────────
const endpollHandler = async ({ reply, jid, sender, isAdmin }) => {
  const poll = pollStore.get(jid)
  if (!poll) return reply('❌ No active poll in this group.')
  if (!poll.active) return reply('❌ Poll is already closed.')
  if (poll.creator !== sender && !isAdmin) {
    return reply('❌ Only the poll creator or admins can end the poll.')
  }

  poll.active = false

  const totalVotes = Object.keys(poll.votes).length
  const counts     = new Array(poll.options.length).fill(0)
  Object.values(poll.votes).forEach(v => counts[v]++)

  const winner    = counts.indexOf(Math.max(...counts))
  const winnerOpt = poll.options[winner]
  const winnerPct = totalVotes ? Math.round((counts[winner] / totalVotes) * 100) : 0

  const results = poll.options.map((opt, i) => {
    const c   = counts[i]
    const pct = totalVotes ? Math.round((c / totalVotes) * 100) : 0
    const bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10))
    return `┃ ${i === winner ? '👑' : '  '} *${i+1}.* ${opt}\n┃    [${bar}] ${pct}% (${c})`
  }).join('\n')

  reply(
`🏁 *POLL ENDED!*
┏🏁═══════════════════╗
┃ ❓ ${poll.question}
╠═══════════════════╣
${results}
╠═══════════════════╣
┃ 🏆 Winner: *${winnerOpt}*
┃ 📊 ${winnerPct}% of ${totalVotes} votes
┃ 🔴 Poll is now CLOSED
┗🏁═══════════════════╝`)
}
endpollHandler.command = ['endpoll', 'closepoll']
endpollHandler.group   = true

// ── .quickvote ────────────────────────────────────────────────────────────────
const quickvoteHandler = async ({ reply, jid, sender, text }) => {
  if (!text) return reply('❓ *Usage:* `.quickvote <question>`\nCreates a quick Yes/No poll.\nExample: `.quickvote Should we play a game?`')

  pollStore.set(jid, {
    question: text,
    options:  ['✅ Yes', '❌ No', '🤔 Maybe'],
    votes:    {},
    creator:  sender,
    createdAt:Date.now(),
    active:   true,
  })

  reply(
`⚡ *QUICK POLL*
┏⚡═══════════════════╗
┃ ❓ ${text}
╠═══════════════════╣
┃♡ *1.* ✅ Yes
┃♡ *2.* ❌ No
┃♡ *3.* 🤔 Maybe
╠═══════════════════╣
┃ ⏳ Poll is OPEN
┗⚡═══════════════════╝

_Vote: \`.vote 1\` \`.vote 2\` \`.vote 3\`_`)
}
quickvoteHandler.command = ['quickvote', 'yesno']
quickvoteHandler.group   = true

module.exports = [
  pollHandler, voteHandler, pollresultHandler,
  endpollHandler, quickvoteHandler,
]
