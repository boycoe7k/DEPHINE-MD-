// ╔═══════════════════════╗
// ║  BOT SETTINGS PLUGIN  ║
// ╚═══════════════════════╝

const config = require('../../config/settings')
const fs     = require('fs-extra')
const path   = require('path')

const modeHandler = async ({ reply, args }) => {
  const m = args[0]?.toLowerCase()
  if (!['public', 'private'].includes(m)) return reply('❓ Usage: `.mode public` or `.mode private`')
  config.mode = m
  reply(`✅ Bot mode set to *${m.toUpperCase()}*`)
}
modeHandler.command = ['mode']
modeHandler.owner   = true

const autostatusHandler = async ({ reply, args }) => {
  const on = args[0]?.toLowerCase() === 'on'
  config.autoStatus = on
  reply(`✅ Auto-status view *${on ? 'enabled' : 'disabled'}*.`)
}
autostatusHandler.command = ['autostatus']
autostatusHandler.owner   = true

const autoreactHandler = async ({ reply, args }) => {
  const on = args[0]?.toLowerCase() === 'on'
  config.autoReact = on
  reply(`✅ Auto-react *${on ? 'enabled' : 'disabled'}*.`)
}
autoreactHandler.command = ['autoreact']
autoreactHandler.owner   = true

const autotypingHandler = async ({ reply, args }) => {
  const on = args[0]?.toLowerCase() === 'on'
  config.autoTyping = on
  reply(`✅ Auto-typing indicator *${on ? 'enabled' : 'disabled'}*.`)
}
autotypingHandler.command = ['autotyping']
autotypingHandler.owner   = true

const autorecordingHandler = async ({ reply, args }) => {
  const on = args[0]?.toLowerCase() === 'on'
  config.autoRecording = on
  reply(`✅ Auto-recording indicator *${on ? 'enabled' : 'disabled'}*.`)
}
autorecordingHandler.command = ['autorecording']
autorecordingHandler.owner   = true

const setbotbioHandler = async ({ conn, reply, text }) => {
  if (!text) return reply('❓ Usage: `.setbotbio Your new bio here`')
  await conn.updateProfileStatus(text)
  reply(`✅ Bot bio updated to: _${text}_`)
}
setbotbioHandler.command = ['setbotbio']
setbotbioHandler.owner   = true

const setppHandler = async ({ conn, msg, reply }) => {
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
  const img = quoted?.imageMessage || msg.message?.imageMessage
  if (!img) return reply('❓ Reply to an image with `.setpp`')
  const stream = await conn.downloadContentFromMessage(img, 'image')
  let buf = Buffer.alloc(0)
  for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
  await conn.updateProfilePicture(conn.user.id, buf)
  reply('✅ Bot profile picture updated!')
}
setppHandler.command = ['setpp']
setppHandler.owner   = true

const cleartmpHandler = async ({ reply }) => {
  const tmpDir = path.join(__dirname, '../../tmp')
  await fs.emptyDir(tmpDir)
  reply('🗑️ Temp folder cleared!')
}
cleartmpHandler.command = ['cleartmp']
cleartmpHandler.owner   = true

const clearsessionHandler = async ({ reply }) => {
  reply('🔄 Clearing session and restarting...')
  setTimeout(async () => {
    await fs.remove(config.authFolder)
    process.exit(0)
  }, 2000)
}
clearsessionHandler.command = ['clearsession']
clearsessionHandler.owner   = true

module.exports = [
  modeHandler, autostatusHandler, autoreactHandler,
  autotypingHandler, autorecordingHandler, setbotbioHandler,
  setppHandler, cleartmpHandler, clearsessionHandler,
]
