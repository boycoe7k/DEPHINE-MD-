// ╔══════════════════════════════════════════════════════════╗
// ║   DEPHINE-MD — SMART TRIGGER SYSTEM                      ║
// ║   • Name trigger: say "dephine" → sweet reply            ║
// ║   • Mood detector: sad/happy/bored → auto response       ║
// ║   • Custom keyword triggers per group                    ║
// ║   • Greeting & goodnight detector                        ║
// ╚══════════════════════════════════════════════════════════╝

const { withChannelForward } = require('../../utils/channelForward')
const config = require('../../config/settings')

// Custom triggers per group: jid => [{ trigger, response }]
const customTriggers = new Map()

const DEPHINE_LOVE_REPLIES = [
  `💗 *Aww, you called my name!* 🌸\n\nHey there gorgeous~ I'm right here for you! ✨\n_"You make every conversation brighter."_ 💕`,
  `🌸 *Yes, darling?* 💗\n\nYou rang? 🌹 I've been waiting just for you~\n_Whatever you need, I'm here!_ 💫`,
  `✨ *Oh my, you said my name!* 👑\n\nMy heart just skipped a beat~ 🌸\n_"Every time you call, it feels like magic."_ 💕`,
  `💕 *DEPHINE is here!* 🌟\n\nHello beautiful soul~ 🌸 You called and I came running! ✨\n_"Because you deserve the best."_ 👑`,
  `🌹 *Did someone say DEPHINE?* 💗\n\nOf course I heard you, love~ 🌸\n_"Like a queen answering her subjects."_ ✨\nHow can I help you today? 💫`,
  `💫 *You whispered my name* 🌸\n\nAnd I felt it across the chat~ 💗\n_"DEPHINE is always listening, always caring."_ 🌹\nWhat can I do for you, sweetheart? ✨`,
  `🌸 *Bestie!* 💗\n\nYou called, I came~ That's what I'm here for! ✨\n_"With DEPHINE by your side, you're never alone."_ 💕`,
  `💖 *My name sounds so sweet when you say it!* 🌸\n\nHello love~ How are you doing today? ✨\n_"You brighten my world just by being here."_ 💫`,
  `👑 *DEPHINE at your service, my love!* 🌸\n\nAsk me anything, I'm all yours~ 💗\n_"Elegant, smart, and always here for you."_ ✨`,
  `🌹 *I heard that!* 💕\n\nSay my name again~ I love how it sounds! 🌸\n_DEPHINE — graceful like a queen, powerful like AI._ 💫`,
]

const MOOD_TRIGGERS = [
  {
    patterns: [/\bi'?m (sad|crying|upset|depressed|hurt|broken)\b/i, /😢|😭|💔|😔|🥺/],
    reply: () => `💗 *Aww, I feel you* 🌸\n\nHey, it's okay to not be okay sometimes. 💕\n_You are stronger than you think, and this feeling will pass._\n\nI'm right here with you~ ✨\n\nType *.joke* for a laugh, or *.compliment* for some love 🌹`,
  },
  {
    patterns: [/\bi'?m (happy|excited|great|amazing|blessed|wonderful|fantastic)\b/i, /😄|🥳|🎉|😁|🔥/],
    reply: () => `🌸 *Yayyy!* 💗\n\nYour happiness makes ME happy! ✨\n_Keep smiling, you deserve every bit of joy!_ 👑\n\nSpread those good vibes~ 💫`,
  },
  {
    patterns: [/\bi'?m (bored|so bored)\b/i, /😑|😐/],
    reply: () => `😄 *Bored? Not on my watch!* 🌸\n\nTry one of these:\n🎲 *.joke* — get a joke\n🎮 *.trivia* — test your knowledge\n🎯 *.dare* — spice it up\n🔮 *.8ball* — ask the universe\n🎵 *.play* — listen to music\n\n_DEPHINE has you covered!_ 💗`,
  },
  {
    patterns: [/\bgood\s?morning\b/i, /\bgm\b/i, /^morning$/i],
    reply: () => {
      const greets = [
        `🌅 *Good Morning, sunshine!* 🌸\n\n_"Every morning is a chance to be better than yesterday."_ ✨\n\nType *.menu* to see what I can do today~ 💗`,
        `☀️ *Rise and shine!* 🌸\n\nGood morning beautiful~ 💗\n_Start your day with a smile and let DEPHINE handle the rest!_ ✨`,
        `🌸 *Good morning!* 💕\n\n_"New day, new blessings, new opportunities!"_ 🌅\n\nHow can I make your day amazing? 💗`,
      ]
      return greets[Math.floor(Math.random() * greets.length)]
    },
  },
  {
    patterns: [/\bgood\s?night\b/i, /\bgn\b/i, /^night$/i, /^nite$/i],
    reply: () => {
      const nights = [
        `🌙 *Goodnight, gorgeous!* 🌸\n\n_"Dream big, sleep tight, wake up ready to shine."_ ✨\n\nSweet dreams~ 💕 I'll be here when you wake up! 👑`,
        `💫 *Sleep well, darling!* 🌙\n\n_"May your dreams be as beautiful as you are."_ 🌸\n\nGoodnight from DEPHINE~ 💗`,
        `🌟 *Nighty night!* 🌸\n\nRest well beautiful soul~ 💗\n_"Tomorrow holds new magic just for you."_ 🌙✨`,
      ]
      return nights[Math.floor(Math.random() * nights.length)]
    },
  },
  {
    patterns: [/\bi love you\b/i, /\bilove u\b/i, /\bi luv u\b/i, /\bily\b/i],
    reply: () => `💗 *Awwww!* 🌸\n\nI love you too, darling~ ❤️\n_"Love is the most beautiful thing in the world."_ 💕\n\nYou made DEPHINE blush! 🌹✨`,
  },
  {
    patterns: [/\bthank\s?you\b/i, /\bthanks\b/i, /\bthank u\b/i, /\bthx\b/i, /\bty\b/i],
    reply: () => {
      const replies = [
        `🌸 *You're so welcome!* 💗\n\nAnytime, my love~ That's what I'm here for! ✨\n_"Your smile is my reward."_ 💕`,
        `💕 *Always!* 🌸\n\nNo need to thank me~ Helping you is my pleasure! ✨\n_DEPHINE loves serving you!_ 👑`,
        `✨ *Of course!* 💗\n\nYou deserve the best always~ 🌸\n_"That's what DEPHINE is here for!"_ 💫`,
      ]
      return replies[Math.floor(Math.random() * replies.length)]
    },
  },
  {
    patterns: [/\bwho are you\b/i, /\bwhat are you\b/i, /\bwhat is dephine\b/i],
    reply: () => `🌸 *I am DEPHINE!* 💗\n\n┏👑═══════════════════╗\n┃ 💗 Elegant AI Assistant\n┃ ⚡ Smart WhatsApp Bot\n┃ 👑 Powered by Dephine AI\n┃ 📞 Owner: +${config.ownerNum}\n┗👑═══════════════════╝\n\n_Type_ *.menu* _to see everything I can do!_ ✨`,
  },
]

// ── .addtrigger ───────────────────────────────────────────────────────────────
const addtriggerHandler = async ({ jid, reply, isAdmin, text }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  const parts = text.split('|').map(s => s.trim())
  if (parts.length < 2) return reply(
`❓ *Usage:* \`.addtrigger <keyword> | <response>\`

Examples:
\`.addtrigger rules | Please read the pinned message! 📌\`
\`.addtrigger hello | Welcome! Type .menu for commands 🌸\`
\`.addtrigger link | No links allowed in this group! ❌\``)

  const trigger  = parts[0].toLowerCase()
  const response = parts.slice(1).join('|').trim()

  if (!customTriggers.has(jid)) customTriggers.set(jid, [])
  const list = customTriggers.get(jid)
  const idx  = list.findIndex(t => t.trigger === trigger)

  if (idx >= 0) {
    list[idx].response = response
    return reply(`✅ *Trigger updated!*\n\n🔑 Keyword: _${trigger}_\n💬 Response: _${response}_`)
  }
  if (list.length >= 25) return reply('❌ Max 25 custom triggers per group.')
  list.push({ trigger, response })
  reply(`✅ *Trigger added!*\n\n🔑 Keyword: _"${trigger}"_\n💬 Response: _${response}_\n\n_Anyone who types "${trigger}" will get this auto-reply._ 🌸`)
}
addtriggerHandler.command = ['addtrigger', 'settrigger']
addtriggerHandler.group   = true
addtriggerHandler.admin   = true

// ── .deltrigger ───────────────────────────────────────────────────────────────
const deltriggerHandler = async ({ jid, reply, isAdmin, text }) => {
  if (!isAdmin) return reply('💗 Admins only.')
  if (!text) return reply('❓ Usage: `.deltrigger <keyword>`')
  const list = customTriggers.get(jid) || []
  const idx  = list.findIndex(t => t.trigger === text.toLowerCase().trim())
  if (idx < 0) return reply(`❌ Trigger *"${text}"* not found. Use *.triggers* to see the list.`)
  list.splice(idx, 1)
  reply(`🗑️ Trigger *"${text}"* deleted successfully.`)
}
deltriggerHandler.command = ['deltrigger', 'removetrigger']
deltriggerHandler.group   = true
deltriggerHandler.admin   = true

// ── .triggers ─────────────────────────────────────────────────────────────────
const listtriggersHandler = async ({ jid, reply }) => {
  const list = customTriggers.get(jid) || []
  if (!list.length) return reply(
`📋 *No custom triggers set.*\n\nAdd one with:\n\`.addtrigger rules | Read the pinned post!\``)
  reply(
`📋 *Custom Triggers (${list.length}/25)*
┏📋═══════════════════╗
${list.map((t, i) => `┃ *${i+1}.* _${t.trigger}_\n┃    → ${t.response.slice(0,45)}${t.response.length>45?'...':''}`).join('\n')}
┗📋═══════════════════╝

_Use_ \`.deltrigger <keyword>\` _to remove one._`)
}
listtriggersHandler.command = ['triggers', 'listtriggers', 'showtriggers']
listtriggersHandler.group   = true

// ── Main processor — called from index.js on EVERY message ────────────────────
async function processTriggers(conn, m) {
  const msg = m.messages?.[0]
  if (!msg || msg.key.fromMe) return

  const jid  = msg.key.remoteJid
  const body = (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption || ''
  ).trim()

  if (!body || body.startsWith(config.prefix)) return

  const lower = body.toLowerCase()

  // 1. DEPHINE name trigger (highest priority)
  if (/\bdephine\b/i.test(body)) {
    const r = DEPHINE_LOVE_REPLIES[Math.floor(Math.random() * DEPHINE_LOVE_REPLIES.length)]
    return conn.sendMessage(jid, withChannelForward({ text: r }), { quoted: msg })
  }

  // 2. Custom group triggers
  const list = customTriggers.get(jid) || []
  for (const t of list) {
    if (lower.includes(t.trigger)) {
      return conn.sendMessage(jid, withChannelForward({ text: t.response }), { quoted: msg })
    }
  }

  // 3. Mood / emotion / greeting detectors
  for (const mood of MOOD_TRIGGERS) {
    if (mood.patterns.some(p => p.test(body))) {
      return conn.sendMessage(jid, withChannelForward({ text: mood.reply() }), { quoted: msg })
    }
  }
}

module.exports = Object.assign(
  [addtriggerHandler, deltriggerHandler, listtriggersHandler],
  { processTriggers }
)
