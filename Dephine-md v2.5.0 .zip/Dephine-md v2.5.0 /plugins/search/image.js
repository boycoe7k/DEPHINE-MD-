// ╔══════════════════════╗
// ║  IMAGE SEARCH PLUGIN ║
// ╚══════════════════════╝

const axios = require('axios')
const fs    = require('fs-extra')
const path  = require('path')

const TMP = path.join(__dirname, '../../tmp')
fs.ensureDirSync(TMP)

const imageHandler = async ({ conn, jid, msg, reply, text }) => {
  if (!text) return reply('❓ Usage: `.image <query>`')
  reply(`🔍 Searching images for: _${text}_`)

  try {
    // Using Unsplash random photo endpoint (free, no key needed for demo)
    const { data } = await axios.get(
      `https://api.unsplash.com/photos/random?query=${encodeURIComponent(text)}&client_id=demo`,
      { timeout: 8000 }
    )

    const url = data?.urls?.regular
    if (!url) throw new Error('No image found')

    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 })
    const out = path.join(TMP, `img_${Date.now()}.jpg`)
    await fs.outputFile(out, res.data)

    await conn.sendMessage(jid, {
      image: fs.readFileSync(out),
      caption:
        `🖼️ *Image: ${text}*\n` +
        `📸 ${data.user?.name || 'Unsplash'}\n` +
        `🔗 ${data.links?.html || ''}`,
    }, { quoted: msg })

    fs.remove(out)
  } catch (e) {
    // Fallback: send DuckDuckGo image search link
    reply(
      `🔍 *Image Search: ${text}*\n\n` +
      `🔗 https://duckduckgo.com/?q=${encodeURIComponent(text)}&iax=images&ia=images\n\n` +
      `_Open the link to see images._`
    )
  }
}
imageHandler.command = ['image', 'img', 'photo']

module.exports = imageHandler
