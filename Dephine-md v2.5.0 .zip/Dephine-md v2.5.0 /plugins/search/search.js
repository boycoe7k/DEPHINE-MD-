// ╔══════════════════════╗
// ║   SEARCH COMMANDS    ║
// ╚══════════════════════╝

const axios = require('axios')

// ── Google (scrape via API) ───────────────────────────────────────────────────
const googleHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.google <query>`')
  try {
    const { data } = await axios.get(
      `https://ddg-api.herokuapp.com/search?query=${encodeURIComponent(text)}&limit=3`
    )
    if (!data.length) return reply('❌ No results found.')
    let msg = `🔎 *Google Results:* _${text}_\n\n`
    data.forEach((r, i) => {
      msg += `*${i + 1}.* ${r.title}\n${r.snippet}\n🔗 ${r.link}\n\n`
    })
    reply(msg.trim())
  } catch (e) {
    reply(`❌ Search failed: ${e.message}`)
  }
}
googleHandler.command = ['google', 'search']

// ── Wikipedia ─────────────────────────────────────────────────────────────────
const wikiHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.wiki <topic>`')
  try {
    const { data } = await axios.get(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text)}`
    )
    reply(`📚 *${data.title}*\n\n${data.extract}\n\n🔗 ${data.content_urls?.desktop?.page || ''}`)
  } catch (e) {
    reply(`❌ Wiki error: ${e.message}`)
  }
}
wikiHandler.command = ['wiki', 'wikipedia']

// ── Weather ───────────────────────────────────────────────────────────────────
const weatherHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.weather <city>`')
  try {
    const { data } = await axios.get(
      `https://wttr.in/${encodeURIComponent(text)}?format=4`
    )
    reply(`🌤️ *Weather for ${text}:*\n${data}`)
  } catch (e) {
    reply(`❌ Weather error: ${e.message}`)
  }
}
weatherHandler.command = ['weather']

// ── Translate ─────────────────────────────────────────────────────────────────
const translateHandler = async ({ reply, args, text }) => {
  if (args.length < 2) return reply('❓ Usage: `.translate <lang_code> <text>`\nExample: `.translate fr Hello world`')
  const [lang, ...words] = args
  const query = words.join(' ')
  try {
    const { data } = await axios.get(
      `https://api.mymemory.translated.net/get?q=${encodeURIComponent(query)}&langpair=en|${lang}`
    )
    reply(`🌐 *Translation (→${lang.toUpperCase()}):*\n${data.responseData.translatedText}`)
  } catch (e) {
    reply(`❌ Translate error: ${e.message}`)
  }
}
translateHandler.command = ['translate', 'tr']

// ── Define ────────────────────────────────────────────────────────────────────
const defineHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.define <word>`')
  try {
    const { data } = await axios.get(
      `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(text)}`
    )
    const entry  = data[0]
    const def    = entry.meanings[0].definitions[0]
    let msg = `📖 *${entry.word}*`
    if (entry.phonetic) msg += ` _(${entry.phonetic})_`
    msg += `\n\n*${entry.meanings[0].partOfSpeech}:* ${def.definition}`
    if (def.example) msg += `\n\n_"${def.example}"_`
    reply(msg)
  } catch (e) {
    reply(`❌ Word not found: ${text}`)
  }
}
defineHandler.command = ['define', 'dict', 'meaning']

// ── GitHub search ─────────────────────────────────────────────────────────────
const githubsearchHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.githubsearch <repo or user>`')
  try {
    const { data } = await axios.get(
      `https://api.github.com/search/repositories?q=${encodeURIComponent(text)}&sort=stars&per_page=3`
    )
    let msg = `👨‍💻 *GitHub Results:* _${text}_\n\n`
    data.items.slice(0, 3).forEach((r, i) => {
      msg += `*${i + 1}.* ${r.full_name}\n⭐ ${r.stargazers_count} | 🍴 ${r.forks_count}\n${r.description || 'No description'}\n🔗 ${r.html_url}\n\n`
    })
    reply(msg.trim())
  } catch (e) {
    reply(`❌ GitHub error: ${e.message}`)
  }
}
githubsearchHandler.command = ['githubsearch', 'github']

// ── News ──────────────────────────────────────────────────────────────────────
const newsHandler = async ({ reply, text }) => {
  const q = text || 'world'
  try {
    const { data } = await axios.get(
      `https://gnews.io/api/v4/search?q=${encodeURIComponent(q)}&max=3&lang=en&token=demo`
    )
    if (!data.articles?.length) return reply('❌ No news found.')
    let msg = `📰 *News: ${q}*\n\n`
    data.articles.forEach((a, i) => {
      msg += `*${i + 1}.* ${a.title}\n${a.source.name} • ${new Date(a.publishedAt).toDateString()}\n🔗 ${a.url}\n\n`
    })
    reply(msg.trim())
  } catch (e) {
    reply(`❌ News error: ${e.message}`)
  }
}
newsHandler.command = ['news']

module.exports = [googleHandler, wikiHandler, weatherHandler, translateHandler, defineHandler, githubsearchHandler, newsHandler]
