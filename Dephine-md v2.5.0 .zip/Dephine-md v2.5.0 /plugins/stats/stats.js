// ╔══════════════════════════════╗
// ║  DEPHINE STATS PLUGIN        ║
// ║  ping · uptime · botinfo etc ║
// ╚══════════════════════════════╝

const { dephineBox, formatUptime } = require('../../utils/format')
const config = require('../../config/settings')
const os = require('os')

// ── .ping / .speed ────────────────────────────────────────────────────────────
const pingHandler = async ({ conn, jid, msg, reply }) => {
  const start = Date.now()
  await conn.sendMessage(jid, { text: '🏓 Pinging...' }, { quoted: msg })
  const ms = Date.now() - start
  const bar = ms < 100 ? '🟢 Excellent' : ms < 300 ? '🟡 Good' : '🔴 Slow'
  reply(
`📊 *DEPHINE Speed Test*
┏📊═══════════════════╗
┃ 🏓 Pong!
╠═══════════════════╣
┃ ⚡ Latency: *${ms}ms*
┃ 📶 Status: ${bar}
┃ 🕐 Time: ${new Date().toLocaleTimeString()}
┗📊═══════════════════╝`)
}
pingHandler.command = ['ping', 'speed']

// ── .uptime / .runtime ────────────────────────────────────────────────────────
const uptimeHandler = async ({ reply }) => {
  const up  = formatUptime(Date.now() - config.startTime)
  const sys = formatUptime(os.uptime() * 1000)
  reply(
`⏱️ *DEPHINE Runtime*
┏📊═══════════════════╗
┃ 📈 Bot Statistics
╠═══════════════════╣
┃ ⏱️  Bot uptime: *${up}*
┃ 🖥️  System uptime: ${sys}
┃ 🧠  RAM used: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB
┃ 💻  Node.js: ${process.version}
┃ 🌐  Platform: ${os.platform()} ${os.arch()}
┗📊═══════════════════╝`)
}
uptimeHandler.command = ['uptime', 'runtime']

// ── .botinfo ──────────────────────────────────────────────────────────────────
const botinfoHandler = async ({ conn, reply }) => {
  const { plugins } = require('../../lib/loader')
  reply(
`🤖 *DEPHINE BOT INFO*
┏👑═══════════════════╗
┃ 🌟 About DEPHINE
╠═══════════════════╣
┃ 🌸  Name: *${config.botName}*
┃ ⚡  Version: v${config.version}
┃ 📞  Owner: +${config.ownerNum}
┃ 🔧  Prefix: \`${config.prefix}\`
┃ 🌐  Mode: ${config.mode.toUpperCase()}
╠═══════════════════╣
┃ 📦  Commands: ${plugins.size}
┃ 💻  Node: ${process.version}
┃ 🧠  RAM: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB
┃ ⏱️  Uptime: ${formatUptime(Date.now() - config.startTime)}
╠═══════════════════╣
┃ 💗 Elegant AI Assistant
┃ 👑 Powered by Dephine AI
┗👑═══════════════════╝

✨ _"Graceful like a queen, powerful like AI."_ ✨`)
}
botinfoHandler.command = ['botinfo']

// ── .commands ─────────────────────────────────────────────────────────────────
const commandsHandler = async ({ reply }) => {
  const { plugins } = require('../../lib/loader')
  const list = [...plugins.keys()].sort().map(c => `${config.prefix}${c}`)
  const chunks = []
  for (let i = 0; i < list.length; i += 20) {
    chunks.push(list.slice(i, i + 20).join('  '))
  }
  reply(
`📜 *ALL ${list.length} DEPHINE COMMANDS*
┏📜═══════════════════╗
┃ Command List
╠═══════════════════╣
${chunks.map(c => `┃ ${c}`).join('\n')}
┗📜═══════════════════╝

_Type any command to use it!_`)
}
commandsHandler.command = ['commands']

// ── .users ────────────────────────────────────────────────────────────────────
const usersHandler = async ({ conn, reply }) => {
  try {
    const contacts = await conn.fetchBlocklist()
    reply(
`👥 *DEPHINE User Stats*
┏📊═══════════════════╗
┃ 📈 Usage Statistics
╠═══════════════════╣
┃ 👤 Registered users: Tracking...
┃ 🚫 Blocked: ${contacts?.length || 0}
┃ ⏱️  Since: ${new Date(config.startTime).toDateString()}
┗📊═══════════════════╝`)
  } catch {
    reply('📊 *Users:* Stats tracking active since bot started.')
  }
}
usersHandler.command = ['users']
usersHandler.owner = true

// ── .groups ───────────────────────────────────────────────────────────────────
const groupsHandler = async ({ conn, reply }) => {
  try {
    const chats = await conn.groupFetchAllParticipating()
    const count = Object.keys(chats).length
    reply(
`🌐 *DEPHINE Group Stats*
┏📊═══════════════════╗
┃ 📈 Group Statistics
╠═══════════════════╣
┃ 🌐 Active groups: *${count}*
┃ 👑 Bot is admin in: checking...
┃ ⏱️  Last updated: ${new Date().toLocaleTimeString()}
┗📊═══════════════════╝`)
  } catch {
    reply('🌐 *Groups:* Use `.botinfo` for full stats.')
  }
}
groupsHandler.command = ['groups']
groupsHandler.owner = true

module.exports = [pingHandler, uptimeHandler, botinfoHandler, commandsHandler, usersHandler, groupsHandler]
