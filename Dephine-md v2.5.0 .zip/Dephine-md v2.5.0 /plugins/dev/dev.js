// ╔══════════════════════╗
// ║   DEV MENU PLUGIN    ║
// ╚══════════════════════╝

const axios  = require('axios')
const { exec } = require('child_process')

// ── GitHub User ───────────────────────────────────────────────────────────────
const githubHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.github <username>`')
  try {
    const { data } = await axios.get(`https://api.github.com/users/${text}`)
    reply(
      `👨‍💻 *GitHub: @${data.login}*\n\n` +
      `📛 Name: ${data.name || 'N/A'}\n` +
      `📝 Bio: ${data.bio || 'N/A'}\n` +
      `📦 Repos: ${data.public_repos}\n` +
      `👥 Followers: ${data.followers} | Following: ${data.following}\n` +
      `🌍 Location: ${data.location || 'N/A'}\n` +
      `🔗 ${data.html_url}`
    )
  } catch {
    reply(`❌ GitHub user not found: _${text}_`)
  }
}
githubHandler.command = ['github', 'git']

// ── Repo Info ─────────────────────────────────────────────────────────────────
const repoHandler = async ({ reply, text }) => {
  if (!text || !text.includes('/')) return reply('❓ Usage: `.repo <owner/repo>`')
  try {
    const { data } = await axios.get(`https://api.github.com/repos/${text}`)
    reply(
      `📦 *Repo: ${data.full_name}*\n\n` +
      `📝 ${data.description || 'No description'}\n\n` +
      `⭐ Stars: ${data.stargazers_count}\n` +
      `🍴 Forks: ${data.forks_count}\n` +
      `⚠️  Issues: ${data.open_issues_count}\n` +
      `💻 Language: ${data.language || 'N/A'}\n` +
      `📅 Updated: ${new Date(data.updated_at).toDateString()}\n` +
      `🔗 ${data.html_url}`
    )
  } catch {
    reply(`❌ Repo not found: _${text}_`)
  }
}
repoHandler.command = ['repo']

// ── Git Clone ─────────────────────────────────────────────────────────────────
const gitcloneHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.gitclone <repo-url>`')
  reply(`📥 *Clone Command:*\n\`\`\`git clone ${text}\`\`\`\n\nRun this in your terminal to clone the repo.`)
}
gitcloneHandler.command = ['gitclone']

// ── Script runner (bash, server-side only) ────────────────────────────────────
const scriptHandler = async ({ reply, text }) => {
  if (!text) return reply('❓ Usage: `.script <bash command>`')
  exec(text, { timeout: 10000 }, (err, stdout, stderr) => {
    const out = stdout || stderr || err?.message || 'No output'
    reply(`💻 *Script Output:*\n\`\`\`\n${out.slice(0, 1000)}\n\`\`\``)
  })
}
scriptHandler.command = ['script']
scriptHandler.owner   = true

module.exports = [githubHandler, repoHandler, gitcloneHandler, scriptHandler]
