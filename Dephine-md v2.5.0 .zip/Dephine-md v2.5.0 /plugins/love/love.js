// ╔══════════════════════╗
// ║   LOVE MENU PLUGIN   ║
// ╚══════════════════════╝

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)] }

const COMPLIMENTS = [
  "Your smile could light up the darkest room. 🌸",
  "You have a heart of gold and a mind of diamonds. 💎",
  "The world is genuinely better because you're in it. 💖",
  "You radiate warmth and kindness wherever you go. ✨",
  "You're the kind of person everyone wishes they had in their life. 👑",
  "Your strength is truly inspiring. Keep shining! 🌟",
]

const FLIRTS = [
  "Are you a magician? Because every time I look at you, everyone else disappears. 💫",
  "Do you have a map? I keep getting lost in your eyes. 🗺️",
  "If you were a song, you'd be the one I play on repeat. 🎵",
  "Is your name Wi-Fi? Because I feel a connection. 📶",
  "You must be made of stardust, because you're out of this world. 🌙",
]

const GOODNIGHTS = [
  "🌙 Goodnight, beautiful soul. May your dreams be as lovely as you are. 🌸",
  "✨ Sleep tight! The stars are watching over you tonight. 💫",
  "🌸 Rest well, darling. Tomorrow holds new magic just for you. 👑",
  "💖 Goodnight! May angels whisper sweet nothings as you sleep. 🌙",
]

const LOVENIGHTS = [
  "🌹 The night is beautiful, but not as beautiful as you. Sleep well, my love. 💕",
  "💗 As the moon rises, my thoughts drift to you. Goodnight, sweetheart. 🌙",
  "✨ Close your eyes and dream of us. Goodnight, my everything. 💫",
]

const SHAYARIS = [
  "🌹 _Tere bina zindagi se koi shikwa nahi,_\n_tere bina zindagi bhi kya zindagi..._",
  "💕 _Mohabbat ki raahon mein kho gaye hum,_\n_teri aankhon ke saaye mein so gaye hum..._",
  "🌸 _Dil se teri yaad nahi jaati,_\n_chahe kitni bhi koshish kar lo..._",
  "✨ _Tu hai toh manzil bhi hai, tu hai toh safar bhi,_\n_tere bina yeh duniya adhoori lagti hai..._",
]

// ── Compliment ────────────────────────────────────────────────────────────────
const complimentHandler = async ({ msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const tag = mentioned[0] ? `@${mentioned[0].split('@')[0]}, ` : ''
  reply(`💗 ${tag}${pick(COMPLIMENTS)}`)
}
complimentHandler.command = ['compliment']

// ── Flirt ─────────────────────────────────────────────────────────────────────
const flirtHandler = async ({ msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const tag = mentioned[0] ? `@${mentioned[0].split('@')[0]}, ` : ''
  reply(`💌 ${tag}${pick(FLIRTS)}`)
}
flirtHandler.command = ['flirt']

// ── Ship ──────────────────────────────────────────────────────────────────────
const shipHandler = async ({ msg, reply, args }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  if (mentioned.length < 2 && args.length < 2) return reply('❓ Tag two people: `.ship @user1 @user2`')
  const a = mentioned[0] ? `@${mentioned[0].split('@')[0]}` : args[0]
  const b = mentioned[1] ? `@${mentioned[1].split('@')[0]}` : args[1]
  const pct = Math.floor(Math.random() * 101)
  const bar = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10))
  const emoji = pct > 80 ? '💞' : pct > 50 ? '💕' : pct > 30 ? '💗' : '💔'
  reply(`${emoji} *Ship Meter*\n\n${a} + ${b}\n\n[${bar}] *${pct}%*\n\n${pct > 80 ? 'Perfect match! 🌸' : pct > 50 ? 'Pretty good couple 💕' : pct > 30 ? 'There is potential! 🌱' : 'Maybe just friends 😅'}`)
}
shipHandler.command = ['ship']

// ── Simp ──────────────────────────────────────────────────────────────────────
const simpHandler = async ({ msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const tag = mentioned[0] ? `@${mentioned[0].split('@')[0]}` : 'you'
  const pct = Math.floor(Math.random() * 101)
  reply(`😤 *Simp Detector*\n\nTarget: ${tag}\nSimp Level: *${pct}%*\n\n${pct > 80 ? '🚨 MAXIMUM SIMP DETECTED' : pct > 50 ? '💗 Mid-tier simp' : '😎 Pretty chill actually'}`)
}
simpHandler.command = ['simp']

// ── Goodnight ─────────────────────────────────────────────────────────────────
const goodnightHandler = async ({ msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const tag = mentioned[0] ? `@${mentioned[0].split('@')[0]}, ` : ''
  reply(`${tag}${pick(GOODNIGHTS)}`)
}
goodnightHandler.command = ['goodnight']

// ── Love Night ────────────────────────────────────────────────────────────────
const lovenightHandler = async ({ msg, reply }) => {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
  const tag = mentioned[0] ? `@${mentioned[0].split('@')[0]}, ` : ''
  reply(`${tag}${pick(LOVENIGHTS)}`)
}
lovenightHandler.command = ['lovenight']

// ── Shayari ───────────────────────────────────────────────────────────────────
const shayariHandler = async ({ reply }) => {
  reply(`🌹 *Shayari by DEPHINE*\n\n${pick(SHAYARIS)}`)
}
shayariHandler.command = ['shayari']

module.exports = [complimentHandler, flirtHandler, shipHandler, simpHandler, goodnightHandler, lovenightHandler, shayariHandler]
