// ╔══════════════════════╗
// ║   FUN ZONE PLUGIN    ║
// ╚══════════════════════╝

const axios = require('axios')

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)] }

// ── Dice ──────────────────────────────────────────────────────────────────────
const diceHandler = async ({ reply }) => {
  const roll  = Math.floor(Math.random() * 6) + 1
  const faces = ['', '\u2680','\u2681','\u2682','\u2683','\u2684','\u2685']
  reply(`\uD83C\uDFB2 You rolled a *${roll}* ${faces[roll]}`)
}
diceHandler.command = ['dice']

// ── Coin ──────────────────────────────────────────────────────────────────────
const coinHandler = async ({ reply }) => {
  const r = Math.random() < 0.5
  reply(`\uD83E\uDE99 The coin landed on: *${r ? 'Heads \uD83D\uDC51' : 'Tails \uD83C\uDF38'}*`)
}
coinHandler.command = ['coin']

// ── Random Number ─────────────────────────────────────────────────────────────
const randomHandler = async ({ reply, text }) => {
  const parts = (text || '1-100').split('-').map(Number)
  const min   = parts[0], max = parts[1]
  if (isNaN(min) || isNaN(max)) return reply('? Usage: `.random 1-100`')
  const n = Math.floor(Math.random() * (max - min + 1)) + min
  reply(`\uD83C\uDFAF Random (${min}-${max}): *${n}*`)
}
randomHandler.command = ['random']

// ── Pick ──────────────────────────────────────────────────────────────────────
const pickHandler = async ({ reply, text }) => {
  if (!text) return reply('? Usage: `.pick pizza|sushi|burgers`')
  const items = text.split(/[|,\/]/).map(s => s.trim()).filter(Boolean)
  if (items.length < 2) return reply('? Provide at least 2 options separated by `|`')
  reply(`\uD83C\uDFAF I pick: *${pick(items)}*`)
}
pickHandler.command = ['pick']

// ── Riddle ────────────────────────────────────────────────────────────────────
const RIDDLES = [
  { q: 'I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?', a: 'An echo' },
  { q: 'The more you take, the more you leave behind. What am I?', a: 'Footsteps' },
  { q: 'I have cities, but no houses. Mountains, but no trees. Water, but no fish. What am I?', a: 'A map' },
  { q: 'What has hands but cannot clap?', a: 'A clock' },
  { q: 'What gets wetter the more it dries?', a: 'A towel' },
  { q: 'I am light as a feather, but the strongest person cannot hold me for five minutes. What am I?', a: 'Breath' },
  { q: 'I have a head and a tail but no body. What am I?', a: 'A coin' },
  { q: 'What runs but never walks, has a mouth but never talks?', a: 'A river' },
]
const riddleHandler = async ({ reply }) => {
  const r = pick(RIDDLES)
  reply(`\uD83E\uDDE9 *Riddle:*\n\n_${r.q}_\n\n||Answer: ${r.a}||`)
}
riddleHandler.command = ['riddle']

// ── Joke ──────────────────────────────────────────────────────────────────────
const jokeHandler = async ({ reply }) => {
  try {
    const { data } = await axios.get('https://official-joke-api.appspot.com/random_joke', { timeout: 8000 })
    reply(`\uD83D\uDE02 *Joke:*\n\n${data.setup}\n\n_${data.punchline}_`)
  } catch {
    const jokes = [
      "Why don't scientists trust atoms?\nBecause they make up everything!",
      "Why did the scarecrow win an award?\nBecause he was outstanding in his field!",
      "I told my wife she was drawing her eyebrows too high.\nShe looked surprised.",
      "What do you call a fish without eyes?\nA fsh!",
      "Why cannot a bicycle stand on its own?\nBecause it is two-tired!",
    ]
    reply(`\uD83D\uDE02 *Joke:*\n\n${pick(jokes)}`)
  }
}
jokeHandler.command = ['joke']

// ── 8Ball ─────────────────────────────────────────────────────────────────────
const EIGHT_BALL = [
  '\u2705 It is certain.',
  '\u2705 Without a doubt.',
  '\u2705 Yes, definitely!',
  '\u2705 You may rely on it.',
  '\u2705 Most likely.',
  '\u26A0\uFE0F Reply hazy, try again.',
  '\u26A0\uFE0F Ask again later.',
  '\u26A0\uFE0F Better not tell you now.',
  '\u274C Don\'t count on it.',
  '\u274C My reply is no.',
  '\u274C Very doubtful.',
  '\uD83C\uDF38 Signs point to yes!',
  '\uD83D\uDCAB The stars say yes~',
]
const eightballHandler = async ({ reply, text }) => {
  if (!text) return reply('? Usage: `.8ball Will I win?`')
  reply(`\uD83C\uDFB1 *Magic 8-Ball*\n\n_"${text}"_\n\n${pick(EIGHT_BALL)}`)
}
eightballHandler.command = ['8ball']

// ── Truth ─────────────────────────────────────────────────────────────────────
const TRUTHS = [
  'What is your biggest fear?',
  'Have you ever lied to your best friend?',
  'What is the most embarrassing thing you have done?',
  'Do you have a secret crush? Who?',
  'What is something you have never told anyone?',
  'Have you ever cheated on a test?',
  'What is your biggest regret in life?',
  'Have you ever ghosted someone?',
  'What is the meanest thing you have ever done?',
  'Have you ever stolen anything?',
]
const truthHandler = async ({ reply }) => {
  reply(`\uD83D\uDCAD *Truth:*\n\n_${pick(TRUTHS)}_`)
}
truthHandler.command = ['truth']

// ── Dare ──────────────────────────────────────────────────────────────────────
const DARES = [
  'Send a voice note saying "I am DEPHINE\'s loyal servant"',
  'Change your profile picture for 1 hour to something funny.',
  'Send a compliment to the last person in your contacts.',
  'Do 20 push-ups and send a photo as proof.',
  'Text someone "I have a confession" and wait for reply.',
  'Send a selfie with the funniest face you can make.',
  'Sing the first 10 seconds of any song in a voice note.',
  'Post a good morning message in your story right now.',
]
const dareHandler = async ({ reply }) => {
  reply(`\uD83D\uDD25 *Dare:*\n\n_${pick(DARES)}_`)
}
dareHandler.command = ['dare']

// ── Trivia ────────────────────────────────────────────────────────────────────
const triviaHandler = async ({ reply }) => {
  try {
    const { data } = await axios.get(
      'https://opentdb.com/api.php?amount=1&type=multiple&encode=url3986',
      { timeout: 8000 }
    )
    const q = data.results[0]
    const decode = s => decodeURIComponent(s)
    const allAnswers = [...q.incorrect_answers, q.correct_answer]
      .map(decode)
      .sort(() => Math.random() - 0.5)
    const labels = ['A', 'B', 'C', 'D']
    const opts   = allAnswers.map((a, i) => `${labels[i]}. ${a}`).join('\n')
    reply(
`\uD83E\uDDE0 *Trivia — ${decode(q.category)}*
_Difficulty: ${decode(q.difficulty)}_

${decode(q.question)}

${opts}

||Answer: ${decode(q.correct_answer)}||`)
  } catch {
    reply('\u274C Could not load trivia right now. Try again in a moment!')
  }
}
triviaHandler.command = ['trivia']

module.exports = [
  diceHandler, coinHandler, randomHandler, pickHandler,
  riddleHandler, jokeHandler, eightballHandler,
  truthHandler, dareHandler, triviaHandler,
]
